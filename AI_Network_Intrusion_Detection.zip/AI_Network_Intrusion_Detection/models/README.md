# models/

Trained model files (`.joblib`) are written here:

- `demo_random_forest.joblib` is created automatically the first time you start the app
  (trained on synthetic data in about a second).
- `last_trained_model.joblib` is written when you train a model on the Model Performance page.

Only load model files that this app created on your own computer: joblib files can execute code when loaded.
If a file was saved with a different scikit-learn version and cannot be loaded, the app retrains the demo model.
