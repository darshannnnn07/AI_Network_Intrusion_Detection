"""Page 7 - Live monitor: Demo Mode (simulated) and Live Monitoring Mode (disabled state)."""
import ctypes.util
import importlib.util
import os
import platform

import pandas as pd
import streamlit as st

from src import charts, demo_data, state, ui
from src.config import COLORS

state.ensure_state()
ss = st.session_state

ui.page_header("Live monitor", "Two clearly separated modes: simulated traffic and real packet capture")

mode = st.radio("Mode", ["Demo Mode (simulated traffic)", "Live Monitoring Mode (real capture)"],
                horizontal=True, key="live_mode")

# ===================================================================== Demo Mode
if mode.startswith("Demo"):
    ui.html_block(f'<div style="margin-bottom:10px">{ui.badge("SIMULATED", "b-demo")} '
                  '<span class="stamp">Synthetic events. No packets are captured from any network. No special privileges needed.</span></div>')
    c1, c2, c3, c4 = st.columns(4)
    c1.toggle("Run simulated stream", key="live_running")
    per_tick = c2.slider("Events per update", 5, 60, 20, key="live_per")
    interval = c3.slider("Seconds between updates", 1, 5, 2, key="live_int")
    ratio = c4.slider("Attack share", 0.05, 0.6, 0.2, step=0.05, key="live_ratio")
    b1, b2 = st.columns(2)
    if b1.button("Clear stream", width="stretch", key="live_clear"):
        ss.live_buffer, ss.live_total, ss.live_threats = None, 0, 0
        st.rerun()
    if b2.button("Use stream as dashboard data", width="stretch", key="live_adopt",
                 disabled=ss.live_buffer is None or len(ss.live_buffer) < 5):
        state.set_dashboard(ss.live_buffer.copy(), "stream", "Simulated live stream (synthetic)")
        st.success("The Security Overview, Threat Alerts and Traffic Explorer pages now show this stream.")

    @st.fragment(run_every=interval if ss.get("live_running") else None)
    def stream():
        if ss.get("live_running"):
            batch = demo_data.generate_stream_batch(per_tick, seed=1000 + ss.live_total, attack_ratio=ratio)
            scored = state.score_df(batch)
            buf = scored if ss.live_buffer is None else pd.concat([ss.live_buffer, scored], ignore_index=True)
            ss.live_buffer = buf.tail(1500).reset_index(drop=True)
            ss.live_total += len(scored)
            ss.live_threats += int(scored["is_suspicious"].sum())
        buf = ss.live_buffer
        k = st.columns(3)
        k[0].metric("Events received", f"{ss.live_total:,}")
        k[1].metric("Flagged suspicious", f"{ss.live_threats:,}")
        k[2].metric("Status", "Streaming" if ss.get("live_running") else "Paused")
        if buf is None or buf.empty:
            st.info("Turn on 'Run simulated stream' to start generating demonstration events.")
            return
        with ui.card("live_chart"):
            ui.show(charts.traffic_over_time(buf, "Simulated events over time", 300), "live_chart_fig")
        view = buf.sort_values("timestamp", ascending=False).head(12)
        out = pd.DataFrame({"Time": view["timestamp"].astype(str).str.slice(11, 19), "Source IP": view["src_ip"],
                            "Destination IP": view["dst_ip"], "Protocol": view["protocol"],
                            "Dest. port": view["dst_port"], "Classification": view["traffic_class"],
                            "Category": view["prediction"], "Risk score": view["risk_score"]})
        st.dataframe(ui.style_table(out, ["Classification"], ["Risk score"]), hide_index=True, width="stretch", height=450)

    stream()

# ===================================================================== Live mode
else:
    def is_admin():
        try:
            if os.name == "nt":
                return bool(ctypes.windll.shell32.IsUserAnAdmin())
            return os.geteuid() == 0
        except Exception:
            return False

    if os.name == "nt":
        pcap = os.path.exists(r"C:\Windows\System32\Npcap") or os.path.exists(r"C:\Windows\System32\wpcap.dll")
        pcap_name = "Npcap (Windows packet capture driver)"
    else:
        pcap = ctypes.util.find_library("pcap") is not None
        pcap_name = "libpcap"
    checks = [
        ("scapy Python package", importlib.util.find_spec("scapy") is not None, "pip install scapy"),
        (pcap_name, pcap, "Install Npcap from npcap.com (Windows) or libpcap (Linux/macOS)"),
        ("Administrator / root privileges", is_admin(), "Start the terminal as Administrator (Windows) or use sudo"),
        ("Flow feature extractor", False, "Not included in this version (see the plan below)"),
    ]
    ui.html_block(f'<div style="margin-bottom:10px">{ui.badge("NOT AVAILABLE IN THIS VERSION", "b-info")} '
                  f'<span class="stamp">Platform: {ui.esc(platform.system())} {ui.esc(platform.release())}</span></div>')
    ui.note("Live capture is switched off in this version. The app does not capture any traffic in this mode and it "
            "never substitutes simulated data here. Use Demo Mode for demonstrations.", "warn")
    with ui.card("live_checks"):
        ui.card_title("Prerequisites on this computer")
        st.dataframe(pd.DataFrame({"Requirement": [c[0] for c in checks],
                                   "Present": ["Yes" if c[1] else "No" for c in checks],
                                   "How to get it": [c[2] for c in checks]}), hide_index=True, width="stretch")
        st.caption("Even if the first three are present, capture stays disabled until a flow extractor is added.")
    st.button("Start live capture (unavailable)", disabled=True, key="live_start")
    with ui.card("live_plan"):
        ui.card_title("How live monitoring could be added later")
        st.markdown("""
1. Capture packets passively with scapy or pyshark on an interface you own or are authorised to monitor. No scanning or probing.
2. Group packets into flows (5-tuple with timeouts) and compute the same features the model uses: durations, packet and byte counts, packet-length statistics and rates. Tools such as CICFlowMeter do this.
3. Pass each completed flow to `detection_model.predict_frame()`, the same function Demo Mode and CSV analysis use.
4. Append the scored flows to the dashboard buffer so every page updates.

Permissions: packet capture needs administrator or root rights, and you must have permission to monitor the network.
""")
