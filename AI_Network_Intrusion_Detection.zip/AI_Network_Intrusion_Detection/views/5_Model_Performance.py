"""Page 5 - Model performance: evaluation, training on your own data, metric guide."""
import pandas as pd
import streamlit as st

from src import charts, data_loader, demo_data, state, ui
from src import detection_model as dm
from src.config import COLORS, MAX_TRAINING_ROWS, MODELS_DIR
from src.preprocessing import DataError, detect_label_column, split_feature_types, suggest_features

state.ensure_state()
ss = st.session_state
model = ss.model

ui.page_header("Model performance", "Evaluate the detection model on held-out data")


def pct(v):
    return "n/a" if v is None else f"{v:.3f}"


def render_evaluation(m: dm.ModelBundle) -> None:
    ev = m.evaluation
    if not ev:
        st.info("This model has no stored evaluation. Train a model below to create one.")
        return
    scope = "a synthetic demonstration dataset" if m.synthetic else f"user-uploaded data ({m.source})"
    ui.note(f"Results below were measured on a held-out test split of {scope}. "
            + ("They illustrate the evaluation workflow and say nothing about performance on real networks."
               if m.synthetic else "They describe this dataset only and may not carry over to other networks."), "warn")
    tr, te = ev["train"]["binary"], ev["test"]["binary"]

    k = st.columns(6)
    k[0].metric("Accuracy", pct(te["accuracy"]))
    k[1].metric("Precision", pct(te["precision"]))
    k[2].metric("Recall", pct(te["recall"]))
    k[3].metric("F1-score", pct(te["f1"]))
    k[4].metric("False positive rate", pct(te["fpr"]))
    k[5].metric("ROC AUC", pct(te["auc"]))
    st.caption("Test-set values for Normal vs Suspicious (positive class = Suspicious).")

    c1, c2 = st.columns(2)
    with c1:
        with ui.card("mp_cmp"):
            ui.show(charts.metrics_compare(tr, te), "mp_cmp_fig")
    with c2:
        with ui.card("mp_roc"):
            ui.show(charts.roc_fig(ev["test"]["roc"], te["auc"]), "mp_roc_fig")

    gap = (tr["accuracy"] or 0) - (te["accuracy"] or 0)
    st.dataframe(pd.DataFrame({
        "Split": ["Training (fit on this)", "Test (held out)"],
        "Rows": [m.n_train, m.n_test],
        "Accuracy": [tr["accuracy"], te["accuracy"]], "Precision": [tr["precision"], te["precision"]],
        "Recall": [tr["recall"], te["recall"]], "F1-score": [tr["f1"], te["f1"]],
        "False positive rate": [tr["fpr"], te["fpr"]]}).round(4), hide_index=True, width="stretch")
    if gap > 0.03:
        st.warning(f"Training accuracy is {gap * 100:.1f} points higher than test accuracy. Training numbers are "
                   "always optimistic because the model has seen those rows; judge the model by the test split.")

    base = ev["test"]["baseline"]
    if base["always_normal_accuracy"] is not None:
        ui.note(f"Why accuracy alone can mislead: in this test split {base['attack_share'] * 100:.1f}% of flows are "
                f"attacks, so a useless detector that always answers 'Normal' would still score "
                f"{base['always_normal_accuracy'] * 100:.1f}% accuracy while catching nothing. Recall (attacks "
                "caught), precision (alerts that were real) and false positive rate matter more for intrusion detection.")

    t1, t2, t3 = st.tabs(["Confusion matrices", "Classification report", "Feature importance"])
    with t1:
        cc = st.columns(2)
        b = ev["test"]["binary"]
        with cc[0]:
            with ui.card("mp_cm_bin"):
                ui.show(charts.confusion_heatmap([[b["tn"], b["fp"]], [b["fn"], b["tp"]]], ["Normal", "Suspicious"],
                                                 "Normal vs Suspicious (test set)"), "mp_cm_bin_fig")
        with cc[1]:
            with ui.card("mp_cm_multi"):
                labels = ev["test"]["class_labels"]
                if len(labels) > 2:
                    ui.show(charts.confusion_heatmap(ev["test"]["multiclass_cm"], labels, "Per-class (test set)", 340), "mp_cm_multi_fig")
                else:
                    ui.show(charts.empty("Model was trained with two classes.", 340, "Per-class (test set)"), "mp_cm_multi_fig")
    with t2:
        rep = pd.DataFrame(ev["test"]["report"])
        st.dataframe(rep.round(4), hide_index=True, width="stretch")
        st.caption("Per-class precision, recall and F1 on the held-out test split.")
    with t3:
        with ui.card("mp_imp"):
            ui.show(charts.importance_bar(m.importances), "mp_imp_fig")
        st.caption("Importance values show how much each feature contributed to the model overall. They do not "
                   "explain individual predictions.")

    if ev.get("comparison"):
        cmp_ = ev["comparison"]
        st.markdown("##### Comparison model (same split)")
        ct = cmp_["test"]
        st.dataframe(pd.DataFrame({
            "Model": [m.model_type, cmp_["model_type"]],
            "Accuracy": [te["accuracy"], ct["accuracy"]], "Precision": [te["precision"], ct["precision"]],
            "Recall": [te["recall"], ct["recall"]], "F1-score": [te["f1"], ct["f1"]],
            "False positive rate": [te["fpr"], ct["fpr"]]}).round(4), hide_index=True, width="stretch")


tab_eval, tab_train, tab_guide = st.tabs(["Active model", "Train on a dataset", "Metric guide"])

# ======================================================================== active model
with tab_eval:
    with ui.card("mp_info"):
        ui.card_title("Active detection model")
        ui.html_block(f"""
        <div class="kv">
          <div class="k">Algorithm</div><div class="v">{ui.esc(model.model_type)}</div>
          <div class="k">Trained on</div><div class="v">{ui.esc(model.source)}</div>
          <div class="k">Trained at</div><div class="v">{ui.esc(model.trained_at)}</div>
          <div class="k">Target</div><div class="v">{ui.esc(model.target_mode)} - {ui.esc(', '.join(model.classes))}</div>
          <div class="k">Features ({len(model.feature_columns)})</div><div class="v">{ui.esc(', '.join(model.feature_columns))}</div>
          <div class="k">Rows (train / test)</div><div class="v">{model.n_train:,} / {model.n_test:,}</div>
        </div>""")
        if st.button("Restore default demo model", key="mp_restore"):
            ss.model = state.load_default_model()
            st.rerun()
    render_evaluation(model)

# ======================================================================== train
with tab_train:
    st.markdown("Train a new model on a labelled dataset. The data is split into training and test sets "
                f"first; preprocessing and the classifier are fitted on the training split only. Up to "
                f"{MAX_TRAINING_ROWS:,} rows are used.")
    src = st.radio("Dataset", ["Synthetic demonstration dataset", "Upload a labelled CSV"], horizontal=True, key="tr_src")
    train_df, label_default, source_name, synthetic = None, None, "", False

    if src == "Synthetic demonstration dataset":
        c1, c2 = st.columns(2)
        n = c1.slider("Rows to generate", 2000, 30000, 8000, step=1000, key="tr_n")
        sd = c2.number_input("Random seed", 0, 99999, 7, key="tr_seed")
        train_df = demo_data.generate_flows(n=int(n), seed=int(sd), attack_ratio=0.35)
        label_default, source_name, synthetic = "label", f"synthetic demonstration dataset ({n:,} rows, seed {sd})", True
    else:
        up = st.file_uploader("Labelled CSV (needs a label column and numeric features)", type=["csv"], key="tr_upload")
        st.download_button("Sample labelled CSV (synthetic)", data_loader.sample_csv_bytes(3000), "sample_labelled.csv",
                           "text/csv", key="tr_sample")
        if up is None:
            st.info("A labelled dataset is needed to train and evaluate. Each row should be one network flow and one "
                    "column should hold the class (for example Normal / BENIGN / attack names, or 0 / 1).")
        else:
            try:
                train_df, renamed, notes = state.canonical_upload(up)
                label_default, source_name = detect_label_column(train_df), up.name
                for n_ in notes:
                    st.info(n_)
            except DataError as exc:
                st.error(str(exc))
            except Exception as exc:
                st.error(f"The file could not be read: {exc}")

    if train_df is not None:
        cols = list(train_df.columns)
        label_col = st.selectbox("Label column", cols, index=cols.index(label_default) if label_default in cols else 0,
                                 key="tr_label")
        suggested, dropped = suggest_features(train_df, label_col)
        if src == "Synthetic demonstration dataset":
            suggested = [c for c in demo_data.FEATURE_COLUMNS if c in suggested]
        feats = st.multiselect("Feature columns", cols, default=suggested, key=f"tr_feats_{src}_{label_col}")
        if dropped:
            with st.expander(f"{len(dropped)} columns excluded automatically"):
                st.dataframe(pd.DataFrame(dropped, columns=["Column", "Reason"]), hide_index=True, width="stretch")
        leaky = [c for c in feats if c in ("label", "attack_cat", "attack_category", "attack", "class", "target") and c != label_col]
        if leaky:
            st.warning(f"Possible target leakage: {', '.join(leaky)} look like label columns. Remove them from the features.")

        c1, c2, c3, c4 = st.columns(4)
        mtype = c1.selectbox("Algorithm", dm.MODEL_TYPES, key="tr_model")
        mode = c2.selectbox("Target", ["multiclass", "binary"], key="tr_mode",
                            help="multiclass keeps attack categories; binary groups them as Suspicious.")
        tsize = c3.slider("Test share", 0.1, 0.5, 0.25, step=0.05, key="tr_tsize")
        cmp_ = c4.checkbox("Compare with the other algorithm", value=True, key="tr_cmp")

        with st.expander("Class balance"):
            vc = train_df[label_col].astype(str).value_counts()
            st.dataframe(vc.rename("rows").reset_index().rename(columns={"index": "class", label_col: "class"}),
                         hide_index=True, width="stretch")
            if len(vc) and vc.iloc[0] / max(vc.sum(), 1) > 0.8:
                st.warning("The dataset is imbalanced. Check recall and false positive rate, not just accuracy.")

        if st.button("Train and evaluate", type="primary", key="tr_go"):
            try:
                with st.spinner("Training the model..."):
                    bundle, warns = dm.train_model(train_df, label_col, feats, mtype, mode, float(tsize), 42,
                                                   source=source_name, synthetic=synthetic, compare_baseline=cmp_,
                                                   max_rows=MAX_TRAINING_ROWS)
                    saved = None
                    try:
                        saved = dm.save_model(bundle, state.LAST_MODEL_FILE)
                    except OSError:
                        pass
                ss.model = bundle
                ss.trained_result = {"warnings": warns, "saved": str(saved) if saved else None}
                st.rerun()
            except (DataError, dm.ModelError) as exc:
                st.error(str(exc))
            except Exception as exc:
                st.error(f"Training failed: {exc}")

    if ss.trained_result:
        st.success("Model trained and set as the active detection model. Open the 'Active model' tab for the full "
                   "evaluation.")
        for w in ss.trained_result["warnings"]:
            st.warning(w)
        if ss.trained_result["saved"]:
            st.caption(f"Saved to {ss.trained_result['saved']}")

    saved_file = state.LAST_MODEL_FILE
    if saved_file.exists():
        if st.button("Load last saved trained model", key="tr_load"):
            m = dm.load_model(saved_file)
            if m is None:
                st.error("The saved model could not be loaded (it may come from a different scikit-learn version).")
            else:
                ss.model = m
                st.rerun()
        st.caption("Only load model files that this app created on your own computer; model files can run code when loaded.")

# ======================================================================== guide
with tab_guide:
    st.markdown("""
**Training vs test performance.** Training metrics describe rows the model has already seen and are almost always
optimistic. Test metrics come from rows kept aside before training and are the fair estimate for this dataset.

**Sample vs uploaded data.** Results on the built-in synthetic dataset only show that the pipeline works. Results on
your own labelled data describe that data. Neither proves the model will detect attacks on a real network.

**Metrics (positive class = Suspicious).**
- *Accuracy*: share of all flows classified correctly. Misleading when attacks are rare.
- *Precision*: of the flows flagged Suspicious, how many really were. Low precision means alert fatigue.
- *Recall*: of the real attacks, how many were caught. Low recall means missed attacks.
- *F1-score*: harmonic mean of precision and recall.
- *False positive rate*: share of normal flows wrongly flagged.
- *ROC AUC*: how well the risk score ranks attacks above normal flows, regardless of threshold.

**How leakage is avoided.** The split is made first. Imputation medians, scaling and one-hot categories are learned from
the training split only. Identifier columns (IP addresses, timestamps) and columns that look like labels are excluded
from the features by default.

**What is needed to evaluate on your data.** A CSV with one row per flow, a label column containing a benign value
(Normal, BENIGN or 0) and at least one attack class, plus numeric feature columns such as durations, packet and byte
counts.
""")
