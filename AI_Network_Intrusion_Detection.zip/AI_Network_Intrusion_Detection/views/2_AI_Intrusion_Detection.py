"""Page 2 - AI Intrusion Detection (CSV upload + manual analysis)."""
import numpy as np
import pandas as pd
import streamlit as st

from src import alerts as al
from src import charts, data_loader, evaluation, state, ui
from src import detection_model as dm
from src.config import CATEGORY_COLORS, COLORS, MAX_SCORING_ROWS
from src.demo_data import PRESETS
from src.preprocessing import (DataError, detect_label_column, is_benign_label, prepare_features,
                               validate_manual_record)

state.ensure_state()
ss = st.session_state
model = ss.model

ui.page_header("AI intrusion detection", "Classify network flows as Normal or Suspicious with a trained model")

if model is not None and model.synthetic:
    ui.note("The active model was trained on a synthetic demonstration dataset. Its predictions illustrate the "
            "workflow; they are not evidence of real-world detection performance. Train on your own labelled "
            "data in the Model Performance page.", "warn")
elif model is not None:
    ui.note(f"Active model: {model.short_name}, trained on {model.source}.", "ok")

tab_a, tab_b = st.tabs(["Method A: CSV dataset upload", "Method B: manual traffic analysis"])


# ============================================================ Method A
def render_results(a: dict) -> None:
    df = a["df"]
    st.subheader("Prediction results")
    st.caption(f"Source: {a['name']} - scored with {a['model_name']}")
    for w in a["warnings"]:
        st.warning(w)
    n = len(df)
    susp = int(df["is_suspicious"].sum())
    c = st.columns(5)
    c[0].metric("Rows analyzed", f"{n:,}")
    c[1].metric("Suspicious", f"{susp:,}")
    c[2].metric("Normal", f"{n - susp:,}")
    c[3].metric("Suspicious share", f"{100 * susp / max(n, 1):.1f}%")
    c[4].metric("Average risk score", f"{df['risk_score'].mean():.1f}")
    st.success("The Security Overview, Threat Alerts and Traffic Explorer pages now show this analysis.")

    g1, g2 = st.columns(2)
    with g1:
        with ui.card("pred_dist"):
            vc = df["prediction"].value_counts()
            ui.show(charts.donut(list(vc.index), [int(v) for v in vc.values],
                                 [CATEGORY_COLORS.get(k, COLORS["amber"]) for k in vc.index],
                                 "Predicted classes", center_text=f"{n:,}"), "det_pred_dist")
    with g2:
        with ui.card("risk_hist"):
            ui.show(charts.histogram(df["risk_score"], "Risk score distribution", "risk score (0-100)",
                                     color=COLORS["amber"]), "det_risk_hist")

    st.markdown("##### Scored records")
    view = st.radio("Show", ["All", "Suspicious only", "Normal only"], horizontal=True, key="det_view")
    shown = df if view == "All" else df[df["is_suspicious"]] if view == "Suspicious only" else df[~df["is_suspicious"]]
    shown = shown.sort_values("risk_score", ascending=False)
    lead = ["traffic_class", "prediction", "risk_score", "confidence"]
    rest = [c for c in shown.columns if c not in lead][:12]
    st.dataframe(ui.style_table(shown[lead + rest], ["traffic_class"], ["risk_score"], max_rows=1000),
                 hide_index=True, width="stretch", height=380)
    st.caption(f"Showing up to 1,000 of {len(shown):,} rows. The download contains all analyzed rows.")
    st.download_button("Download predictions (CSV)", a["csv"], file_name="nids_predictions.csv",
                       mime="text/csv", key="det_dl")

    st.markdown("##### Evaluation against the labels in your file")
    m = a.get("metrics")
    if m is None:
        st.info("No label column was selected, so evaluation metrics cannot be calculated. "
                "Select a label column (for example 'label') before running to see accuracy, precision, "
                "recall, F1-score and false positive rate.")
        return
    k = st.columns(5)
    k[0].metric("Accuracy", f"{m['accuracy']:.3f}")
    k[1].metric("Precision", f"{m['precision']:.3f}")
    k[2].metric("Recall", f"{m['recall']:.3f}")
    k[3].metric("F1-score", f"{m['f1']:.3f}")
    k[4].metric("False positive rate", "n/a" if m["fpr"] is None else f"{m['fpr']:.3f}")
    cm = np.array([[m["tn"], m["fp"]], [m["fn"], m["tp"]]])
    with ui.card("det_cm"):
        ui.show(charts.confusion_heatmap(cm, ["Normal", "Suspicious"], "Confusion matrix (uploaded data)"), "det_cm_fig")
    ui.note("These numbers come from your uploaded data, not from the model's own held-out test set. If the model "
            "was trained on the same file, they will look better than they should. A model trained on synthetic "
            "data may perform much worse on real datasets whose feature values and units differ.", "warn")


def method_a() -> None:
    st.markdown("Upload a CSV of flow records. Column names such as `Destination Port` or `Flow Bytes/s` are "
                "matched to the standard names automatically.")
    cols = st.columns([3, 1])
    up = cols[0].file_uploader("Network traffic CSV", type=["csv"], key="det_upload")
    cols[1].write("")
    cols[1].download_button("Sample CSV (synthetic)", data_loader.sample_csv_bytes(), "sample_flows.csv",
                            "text/csv", width="stretch", key="det_sample")
    if up is None:
        if ss.analysis:
            st.divider()
            render_results(ss.analysis)
        else:
            st.info("Upload a CSV to start, or download the synthetic sample above and upload that file.")
        return

    try:
        df, renamed, notes = state.canonical_upload(up)
    except DataError as exc:
        st.error(str(exc))
        return
    except Exception as exc:
        st.error(f"The file could not be read: {exc}")
        return
    for n_ in notes:
        st.info(n_)

    info = data_loader.dataset_overview(df)
    c = st.columns(4)
    c[0].metric("Rows", f"{info['rows']:,}")
    c[1].metric("Columns", f"{info['cols']:,}")
    c[2].metric("Missing values", f"{info['missing_total']:,}")
    c[3].metric("Duplicate rows", f"{info['duplicates']:,}")
    st.markdown("##### Dataset preview")
    st.dataframe(df.head(50), hide_index=True, width="stretch", height=240)
    if info["missing_total"]:
        with st.expander("Missing values by column"):
            st.dataframe(info["missing_table"], hide_index=True, width="stretch")
    if renamed:
        with st.expander(f"{len(renamed)} column names were standardised"):
            st.dataframe(pd.DataFrame({"Original": list(renamed), "Standardised": list(renamed.values())}),
                         hide_index=True, width="stretch")

    # ---- schema validation
    st.markdown("##### Check the model's required features")
    fid = getattr(up, "file_id", up.name)
    missing = [f for f in model.feature_columns if f not in df.columns]
    mapping = {}
    if missing:
        with st.expander("Map columns manually", expanded=True):
            st.caption("Choose which column in your file corresponds to each missing feature.")
            for f in missing:
                choice = st.selectbox(f"{f}", ["(not available)"] + list(df.columns), key=f"map_{fid}_{f}")
                if choice != "(not available)":
                    mapping[f] = choice
    work = df.assign(**{f: df[c] for f, c in mapping.items()}) if mapping else df
    still = [f for f in model.feature_columns if f not in work.columns]
    kind = lambda f: "numeric" if f in model.numeric_columns else "categorical"
    st.dataframe(pd.DataFrame({
        "Feature": model.feature_columns, "Type": [kind(f) for f in model.feature_columns],
        "Status": ["Missing" if f in still else f"Mapped from '{mapping[f]}'" if f in mapping else "Found"
                   for f in model.feature_columns]}), hide_index=True, width="stretch", height=250)
    allow_missing = False
    if still:
        if len(still) == len(model.feature_columns):
            st.error("None of the model's features are present in this file. Check the column names or map them above.")
            return
        st.warning(f"{len(still)} feature(s) are missing: {', '.join(still)}.")
        allow_missing = st.checkbox("Continue anyway (missing features are filled with training medians; "
                                    "results will be less reliable)", key=f"allow_{fid}")
        if not allow_missing:
            st.error("Provide or map the missing features, or tick the box above to continue.")
            return

    # ---- label column
    guess = detect_label_column(work)
    options = ["(none)"] + list(work.columns)
    label_col = st.selectbox("Ground-truth label column (optional, enables evaluation metrics)", options,
                             index=options.index(guess) if guess in options else 0, key=f"label_{fid}")

    if st.button("Run intrusion detection", type="primary", key="det_run"):
        warnings_ = []
        try:
            data = work
            if len(data) > MAX_SCORING_ROWS:
                data = data.head(MAX_SCORING_ROWS)
                warnings_.append(f"Only the first {MAX_SCORING_ROWS:,} rows were analyzed to keep the app responsive.")
            with st.spinner("Preparing features and running the model..."):
                _, rep = prepare_features(data, model.numeric_columns, model.categorical_columns, model.feature_columns)
                if rep["coerced"]:
                    warnings_.append("Non-numeric values were treated as missing in: " +
                                     ", ".join(f"{k} ({v:,})" for k, v in rep["coerced"].items()))
                scored = state.score_df(data, model)
                metrics = None
                if label_col != "(none)":
                    truth = data[label_col].dropna()
                    truth_bin = ~truth.map(is_benign_label).astype(bool)
                    if truth.empty or truth_bin.all():
                        warnings_.append("No benign-like label values (Normal, BENIGN, 0) were found in the label "
                                         "column, so evaluation metrics were skipped.")
                    else:
                        pred = scored.loc[truth.index, "is_suspicious"].to_numpy()
                        metrics = evaluation.binary_metrics(truth_bin.to_numpy().astype(int), pred.astype(int),
                                                            scores=scored.loc[truth.index, "risk_score"].to_numpy())
                keep = [c for c in scored.columns if c in state.PRED_COLS or c in model.feature_columns
                        or c in ("timestamp", "src_ip", "dst_ip") or c == label_col]
                csv = scored[keep].to_csv(index=False).encode("utf-8")
            ss.analysis = dict(name=up.name, df=scored, csv=csv, metrics=metrics, warnings=warnings_,
                               model_name=model.short_name, label_col=label_col)
            state.set_dashboard(scored, "upload", f"{up.name} ({len(scored):,} rows)")
        except (DataError, dm.ModelError) as exc:
            st.error(str(exc))
        except Exception as exc:
            st.error(f"Analysis failed: {exc}")
    if ss.analysis:
        st.divider()
        render_results(ss.analysis)


# ============================================================ Method B
FIELD_KEYS = ["protocol", "src_port", "dst_port", "flow_duration", "total_fwd_packets", "total_bwd_packets",
              "total_fwd_bytes", "total_bwd_bytes", "pkt_len_mean", "pkt_len_std",
              "flow_packets_per_s", "flow_bytes_per_s"]


def _load_preset(name: str) -> None:
    for k, v in PRESETS[name].items():
        ss[f"mf_{k}"] = v


def method_b() -> None:
    st.markdown("Enter the features of a single network flow. Values are validated before the model is run.")
    for k, v in PRESETS["Normal web session"].items():
        ss.setdefault(f"mf_{k}", v)
    ss.setdefault("mf_flow_packets_per_s", 0.0)
    ss.setdefault("mf_flow_bytes_per_s", 0.0)
    ss.setdefault("mf_auto", True)

    st.caption("Load an example (made-up values for demonstration):")
    pc = st.columns(4)
    for col, name in zip(pc, PRESETS):
        col.button(name, key=f"pre_{name}", on_click=_load_preset, args=(name,), width="stretch")

    extra = [f for f in model.feature_columns if f not in FIELD_KEYS] if model is not None else []
    with st.form("manual_form"):
        c1, c2, c3 = st.columns(3)
        c1.selectbox("Protocol", ["TCP", "UDP", "ICMP"], key="mf_protocol")
        c2.number_input("Source port", min_value=0, max_value=65535, step=1, key="mf_src_port")
        c3.number_input("Destination port", min_value=0, max_value=65535, step=1, key="mf_dst_port")
        c1, c2, c3 = st.columns(3)
        c1.number_input("Flow duration (ms)", min_value=0.0, step=10.0, key="mf_flow_duration")
        c2.number_input("Total forward packets", min_value=0, step=1, key="mf_total_fwd_packets")
        c3.number_input("Total backward packets", min_value=0, step=1, key="mf_total_bwd_packets")
        c1, c2, c3 = st.columns(3)
        c1.number_input("Total forward bytes", min_value=0, step=100, key="mf_total_fwd_bytes")
        c2.number_input("Total backward bytes", min_value=0, step=100, key="mf_total_bwd_bytes")
        c3.number_input("Packet length mean (bytes)", min_value=0.0, step=10.0, key="mf_pkt_len_mean")
        c1, c2, c3 = st.columns(3)
        c1.number_input("Packet length std (bytes)", min_value=0.0, step=10.0, key="mf_pkt_len_std")
        c2.number_input("Flow packets per second", min_value=0.0, step=10.0, key="mf_flow_packets_per_s")
        c3.number_input("Flow bytes per second", min_value=0.0, step=1000.0, key="mf_flow_bytes_per_s")
        st.checkbox("Calculate packet and byte rates from duration, packets and bytes "
                    "(the two rate fields above are then ignored)", key="mf_auto")
        extra_vals = {}
        if extra:
            st.markdown("**Additional features required by the active model**")
            ec = st.columns(3)
            for i, f in enumerate(extra):
                with ec[i % 3]:
                    if f in model.categorical_columns:
                        opts = model.category_values.get(f) or ["missing"]
                        extra_vals[f] = st.selectbox(f, opts, key=f"mx_{f}")
                    else:
                        med = (model.reference_stats.get("overall", {}).get(f, {}) or {}).get("median") or 0.0
                        extra_vals[f] = st.number_input(f, value=float(med), key=f"mx_{f}")
        submitted = st.form_submit_button("Analyze traffic", type="primary")

    if not submitted:
        return
    rec = {k: ss[f"mf_{k}"] for k in FIELD_KEYS}
    rec.update(extra_vals)
    if ss["mf_auto"]:
        dur_s = max(rec["flow_duration"], 1.0) / 1000.0
        rec["flow_packets_per_s"] = (rec["total_fwd_packets"] + rec["total_bwd_packets"]) / dur_s
        rec["flow_bytes_per_s"] = (rec["total_fwd_bytes"] + rec["total_bwd_bytes"]) / dur_s
    errors, warns = validate_manual_record(rec)
    for w in warns:
        st.warning(w)
    if errors:
        for e in errors:
            st.error(e)
        return

    st.divider()
    unused = [k for k in FIELD_KEYS if model is not None and k not in model.feature_columns]
    if model is None:
        r = dm.rule_based_assessment(rec)
        susp = r["risk_score"] >= 50
        ui.note("No trained model is loaded, so this is a rule-based demonstration assessment, not a machine "
                "learning prediction.", "warn")
        label, risk, probs, conf_txt = r["prediction"], r["risk_score"], None, None
        refs, expl = [], " ".join(r["reasons"])
    else:
        frame = pd.DataFrame([rec])
        pf = dm.predict_frame(model, frame).iloc[0]
        probs = dm.class_probabilities(model, frame)
        label, risk, susp = pf["prediction"], float(pf["risk_score"]), bool(pf["is_suspicious"])
        compare = label if susp else max((k for k in probs if k != model.benign_label), key=probs.get)
        refs = dm.explain_record(model, rec, compare)
        closer = [r_["feature"] for r_ in refs if r_["closer_to"] != "Normal"]
        if susp:
            expl = (f"The model assigns a risk score of {risk:.0f}/100, meaning most of its decision trees "
                    f"classify this flow as something other than Normal. The most likely category is '{label}'. ")
            expl += (f"Features where your values sit closer to typical '{label}' flows than to typical Normal flows: "
                     f"{', '.join(closer)}." if closer else "")
        else:
            expl = (f"The model assigns a risk score of {risk:.0f}/100, below the 50 threshold, so the flow is "
                    "treated as Normal. ")
            expl += (f"Some features resemble '{compare}' flows ({', '.join(closer)}), but the overall pattern "
                     "was judged closer to normal traffic." if closer else "")
        conf_txt = (f"Model vote share for this class: {pf['confidence']:.0f}%. This is the share of the "
                    "ensemble's votes, not a calibrated probability." if model.model_type == "Random Forest" else
                    f"Model probability for this class: {pf['confidence']:.0f}% (not calibrated).")

    sev = al.severity_for(risk, label, susp)
    left, right = st.columns([1, 1])
    with left:
        kind = "b-suspicious" if susp else "b-normal"
        src_txt = ("Rule-based demonstration" if model is None else
                   f"Machine-learning prediction - {model.short_name}")
        ui.html_block(f"""
        <div class="result">{ui.badge('Suspicious' if susp else 'Normal', kind)} {ui.severity_badge(sev)}
        <div class="result-label">{ui.esc(label)}</div>
        <div class="card-sub">{ui.esc(src_txt)}</div>
        {'<div class="card-sub">' + ui.esc(conf_txt) + '</div>' if conf_txt else ''}</div>""")
        ui.show(charts.gauge(risk), "man_gauge")
        st.caption("Risk score = share of the model's votes for a non-Normal class (0-100).")
    with right:
        if probs:
            with ui.card("man_probs"):
                ui.show(charts.prob_bar(probs), "man_probs_fig")
        ui.note(expl)
        ui.note("Recommended defensive action: " + al.recommended_action(label), "ok" if not susp else "warn")
    if refs:
        st.markdown("##### How your values compare with the training data")
        st.dataframe(pd.DataFrame([{
            "Feature": r_["feature"], "Your value": round(r_["your_value"], 2),
            "Typical Normal": round(r_["normal_median"], 2), f"Typical {compare}": round(r_["compare_median"], 2),
            "Closer to": r_["closer_to"]} for r_ in refs]), hide_index=True, width="stretch")
        st.caption("Reference comparison with training-set medians, ordered by feature importance. "
                   "It is an aid to interpretation, not a causal explanation of the model.")
    if unused:
        st.caption("Fields not used by the active model: " + ", ".join(unused) + ".")


with tab_a:
    method_a()
with tab_b:
    method_b()
