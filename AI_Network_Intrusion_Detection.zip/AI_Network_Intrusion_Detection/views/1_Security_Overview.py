"""Page 1 - Security Overview dashboard."""
import numpy as np
import pandas as pd
import streamlit as st

from src import alerts as al
from src import charts, state, ui
from src.config import APP_NAME, CATEGORY_COLORS, COLORS, SUBTITLE
from src.demo_data import NORMAL_LABEL

state.ensure_state()
ss = st.session_state
df, alerts = ss.dashboard_df, ss.alerts_df
is_demo = ss.data_source in ("demo", "stream")

ui.page_header(APP_NAME, SUBTITLE, status="System online" + (" - Demo Mode" if is_demo else " - Uploaded data analysed"))

# ---- data source + simulation controls
if is_demo:
    ui.note("Everything on this dashboard is synthetic demonstration data. No real network is being monitored.", "warn")
else:
    ui.note(f"Showing analysis of your uploaded dataset: {ss.source_label}. Use 'Reset to demo data' in the sidebar to go back.")

with st.expander("Demo simulation controls", expanded=False):
    c1, c2, c3 = st.columns(3)
    n = c1.slider("Flows to simulate", 1000, 20000, int(ss.sim_params["n"]), step=500)
    ratio = c2.slider("Share of attack traffic", 0.05, 0.60, float(ss.sim_params["attack_ratio"]), step=0.01)
    seed = c3.number_input("Random seed", 0, 99999, int(ss.sim_params["seed"]), step=1)
    b1, b2, b3 = st.columns(3)
    if b1.button("Run new simulation", type="primary", width="stretch"):
        with st.spinner("Simulating and scoring traffic..."):
            state.run_demo_simulation(n, ratio, seed)
        st.rerun()
    if b2.button("Add 250 new events", width="stretch"):
        with st.spinner("Adding events..."):
            state.append_demo_events(250)
        st.rerun()
    if b3.button("Reset sample data", width="stretch"):
        state.reset_demo()
        st.rerun()

# ---- KPIs
total_flows = len(df)
if {"total_fwd_packets", "total_bwd_packets"} <= set(df.columns):
    packets = int(pd.to_numeric(df["total_fwd_packets"], errors="coerce").fillna(0).sum()
                  + pd.to_numeric(df["total_bwd_packets"], errors="coerce").fillna(0).sum())
    pk_txt, pk_hint = f"{packets:,}", f"across {total_flows:,} flows"
else:
    pk_txt, pk_hint = "N/A", "no packet-count columns in this dataset"
threats = int(df["is_suspicious"].sum())
normal_pct = 100 * (1 - threats / total_flows) if total_flows else 0
sev_counts = alerts[alerts["severity"].isin(["Critical", "High"])]["severity"].value_counts() if len(alerts) else pd.Series(dtype=int)
high_total = int(sev_counts.sum())

cols = st.columns(5)
with cols[0]:
    ui.kpi("Total packets analyzed", pk_txt, pk_hint, "packets", COLORS["cyan"])
with cols[1]:
    ui.kpi("Network flows analyzed", f"{total_flows:,}", "one record per connection", "flows", COLORS["cyan"])
with cols[2]:
    ui.kpi("Threats detected", f"{threats:,}", f"{(100 - normal_pct):.1f}% of flows flagged", "threat", COLORS["red"])
with cols[3]:
    ui.kpi("Normal traffic", f"{normal_pct:.1f}%", f"{total_flows - threats:,} flows look benign", "normal", COLORS["green"])
with cols[4]:
    ui.kpi("High-severity alerts", f"{high_total:,}",
           f"Critical {int(sev_counts.get('Critical', 0)):,} / High {int(sev_counts.get('High', 0)):,}", "alert", COLORS["orange"])

st.write("")
# ---- charts row 1
c1, c2 = st.columns([2, 1])
with c1:
    with ui.card("traffic"):
        ui.show(charts.traffic_over_time(df), "ov_time")
with c2:
    with ui.card("split"):
        ui.show(charts.donut(["Normal", "Malicious"], [total_flows - threats, threats],
                             [COLORS["green"], COLORS["red"]], "Normal vs malicious traffic",
                             center_text=f"{normal_pct:.0f}%"), "ov_split")

# ---- charts row 2
susp_cat = df.loc[df["is_suspicious"], "prediction"].value_counts()
sev_all = alerts["severity"].value_counts() if len(alerts) else pd.Series(dtype=int)
c3, c4 = st.columns(2)
with c3:
    with ui.card("cats"):
        ui.show(charts.category_bar(susp_cat), "ov_cat")
with c4:
    with ui.card("sev"):
        ui.show(charts.severity_bar(sev_all), "ov_sev")

# ---- recent alerts + network activity
c5, c6 = st.columns([1, 2])
with c5:
    with ui.card("recent"):
        ui.card_title("Recent security alerts", "Newest suspicious detections")
        recent = alerts[alerts["category"] != NORMAL_LABEL].head(7) if len(alerts) else alerts
        if recent.empty:
            st.write("No suspicious traffic detected.")
        for _, r in recent.iterrows():
            color = COLORS.get({"Critical": "red", "High": "orange", "Medium": "amber", "Low": "cyan"}.get(r["severity"], "slate"))
            ts = "" if pd.isna(r["timestamp"]) else pd.Timestamp(r["timestamp"]).strftime("%H:%M:%S")
            ui.html_block(f"""
            <div class="feed-item"><div class="feed-bar" style="background:{color}"></div>
              <div class="feed-main"><div class="feed-title">{ui.esc(r['category'])} {ui.severity_badge(r['severity'])}</div>
              <div class="feed-meta">{ui.esc(r['src_ip'])} to {ui.esc(r['dst_ip'])}:{ui.esc(int(r['dst_port']) if pd.notna(r['dst_port']) else '-')} - {ui.esc(r['protocol'])} - risk {r['risk_score']:.0f} {ui.esc(ts)}</div></div></div>""")
with c6:
    with ui.card("activity"):
        ui.card_title("Network activity", "Latest flows with the model's classification (risk score is an uncalibrated model score)")
        view = df.copy()
        if "timestamp" in view.columns:
            view = view.sort_values("timestamp", ascending=False)
        view = view.head(14)
        out = pd.DataFrame({
            "Source IP": view.get("src_ip", "N/A"), "Destination IP": view.get("dst_ip", "N/A"),
            "Protocol": view.get("protocol", "N/A"), "Dest. port": view.get("dst_port", np.nan),
            "Classification": view["traffic_class"], "Risk score": view["risk_score"],
            "Timestamp": view["timestamp"].astype(str).str.slice(0, 19) if "timestamp" in view.columns else "N/A",
        })
        st.dataframe(ui.style_table(out, ["Classification"], ["Risk score"]), hide_index=True, width="stretch", height=420)
