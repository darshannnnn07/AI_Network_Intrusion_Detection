"""Page 4 - Network traffic explorer."""
import numpy as np
import pandas as pd
import streamlit as st

from src import charts, data_loader, state, ui
from src import detection_model as dm
from src.config import COLORS
from src.preprocessing import DataError

state.ensure_state()
ss = st.session_state

ui.page_header("Network traffic explorer", "Inspect, search and profile flow records")

source = st.radio("Data source", ["Current dashboard dataset", "Upload a CSV"], horizontal=True, key="ex_source")
df = None
label = ""
if source == "Current dashboard dataset":
    df = ss.dashboard_df
    label = ss.source_label
else:
    c = st.columns([3, 1])
    up = c[0].file_uploader("Network traffic CSV", type=["csv"], key="ex_upload")
    c[1].write("")
    c[1].download_button("Sample CSV (synthetic)", data_loader.sample_csv_bytes(), "sample_flows.csv", "text/csv",
                         width="stretch", key="ex_sample")
    if up is None:
        st.info("Upload a CSV to explore it, or switch back to the current dashboard dataset.")
        st.stop()
    try:
        df, renamed, notes = state.canonical_upload(up)
    except DataError as exc:
        st.error(str(exc))
        st.stop()
    except Exception as exc:
        st.error(f"The file could not be read: {exc}")
        st.stop()
    label = up.name
    for n_ in notes:
        st.info(n_)
    if st.checkbox("Add model risk scores (uses the active detection model)", key="ex_score"):
        try:
            df = state.score_df(df.head(200_000))
        except Exception as exc:
            st.warning(f"Scoring was not possible with this file: {exc}")

if df is None or df.empty:
    st.warning("The dataset is empty.")
    st.stop()

st.caption(f"Dataset: {label}")
st.markdown("##### Preview")
st.dataframe(df.head(50), hide_index=True, width="stretch", height=230)

# ------------------------------------------------------------------ filters
with ui.card("ex_filters"):
    ui.card_title("Filters")
    f1, f2, f3 = st.columns([2, 2, 3])
    has_proto = "protocol" in df.columns
    if has_proto:
        present = sorted(set(df["protocol"].dropna().astype(str)) | {"TCP", "UDP", "ICMP"})
        protos = f1.multiselect("Protocol", present, key="ex_proto", placeholder="All protocols")
    else:
        f1.caption("No protocol column in this dataset.")
        protos = []
    has_cls = "traffic_class" in df.columns
    cls = f2.multiselect("Classification", ["Normal", "Suspicious"], key="ex_cls") if has_cls else []
    if not has_cls:
        f2.caption("Add model risk scores to filter by classification.")
    query = f3.text_input("Search (IP, protocol, label...)", key="ex_query")
    ts = pd.to_datetime(df["timestamp"], errors="coerce") if "timestamp" in df.columns else None
    time_range = None
    if ts is not None and ts.notna().sum() > 1:
        lo, hi = ts.min().to_pydatetime(), ts.max().to_pydatetime()
        if lo < hi:
            time_range = st.slider("Time range", lo, hi, (lo, hi), format="YYYY-MM-DD HH:mm:ss", key="ex_time")
            if time_range == (lo, hi):
                time_range = None  # full range selected: do not filter

mask = pd.Series(True, index=df.index)
if protos:
    mask &= df["protocol"].astype(str).isin(protos)
if cls:
    mask &= df["traffic_class"].isin(cls)
if time_range is not None:
    mask &= (ts >= pd.Timestamp(time_range[0])) & (ts <= pd.Timestamp(time_range[1]))
if query.strip():
    text_cols = [c for c in df.columns if not pd.api.types.is_numeric_dtype(df[c])][:8] or list(df.columns[:4])
    q = query.strip()
    hit = pd.Series(False, index=df.index)
    for c in text_cols:
        hit |= df[c].astype(str).str.contains(q, case=False, regex=False, na=False)
    mask &= hit
view = df[mask]
st.caption(f"{len(view):,} of {len(df):,} records match the filters.")
if view.empty:
    st.info("No records match the current filters.")
    st.stop()

st.markdown("##### Records")
st.dataframe(ui.style_table(view, ["traffic_class"], ["risk_score"], max_rows=1000), hide_index=True,
             width="stretch", height=340)
st.download_button("Download filtered records (CSV)", view.head(200_000).to_csv(index=False).encode("utf-8"),
                   "filtered_traffic.csv", "text/csv", key="ex_dl")

# ------------------------------------------------------------------ summaries
num = lambda c: pd.to_numeric(view[c], errors="coerce")
k = st.columns(4)
k[0].metric("Records", f"{len(view):,}")
k[1].metric("Unique source IPs", f"{view['src_ip'].nunique():,}" if "src_ip" in view else "n/a")
k[2].metric("Unique destination IPs", f"{view['dst_ip'].nunique():,}" if "dst_ip" in view else "n/a")
k[3].metric("Unique destination ports", f"{view['dst_port'].nunique():,}" if "dst_port" in view else "n/a")

r1 = st.columns(2)
with r1[0]:
    with ui.card("ex_proto"):
        if has_proto:
            vc = view["protocol"].astype(str).value_counts().head(8)
            pal = [COLORS["cyan"], COLORS["green"], COLORS["amber"], COLORS["violet"], COLORS["orange"],
                   COLORS["red"], COLORS["slate"], "#38BDF8"]
            ui.show(charts.donut(list(vc.index), [int(v) for v in vc.values], pal[:len(vc)], "Protocol distribution"), "ex_proto_fig")
        else:
            ui.show(charts.empty("No protocol column.", 330, "Protocol distribution"), "ex_proto_fig")
with r1[1]:
    with ui.card("ex_ports"):
        if "dst_port" in view.columns:
            ports = view["dst_port"].dropna().astype(int, errors="ignore").astype(str).value_counts().head(12)
            ui.show(charts.top_bar(ports, "Top destination ports", COLORS["violet"], 330), "ex_ports_fig")
        else:
            ui.show(charts.empty("No destination-port column.", 330, "Port distribution"), "ex_ports_fig")

r2 = st.columns(2)
with r2[0]:
    with ui.card("ex_src"):
        ui.show(charts.top_bar(view["src_ip"].astype(str).value_counts() if "src_ip" in view else pd.Series(dtype=int),
                               "Top source IPs", COLORS["cyan"]), "ex_src_fig")
with r2[1]:
    with ui.card("ex_dst"):
        ui.show(charts.top_bar(view["dst_ip"].astype(str).value_counts() if "dst_ip" in view else pd.Series(dtype=int),
                               "Top destination IPs", COLORS["green"]), "ex_dst_fig")

r3 = st.columns([2, 1])
with r3[0]:
    with ui.card("ex_vol"):
        ui.show(charts.volume_over_time(view.assign(timestamp=ts[mask]) if ts is not None else view), "ex_vol_fig")
with r3[1]:
    with ui.card("ex_pk"):
        if {"total_fwd_packets", "total_bwd_packets"} <= set(view.columns):
            tot = num("total_fwd_packets").fillna(0) + num("total_bwd_packets").fillna(0)
            ui.show(charts.histogram(tot, "Packets per flow", "packets", COLORS["cyan"], 300, log_x=True), "ex_pk_fig")
        else:
            ui.show(charts.empty("Packet-count columns not available.", 300, "Packets per flow"), "ex_pk_fig")

num_cols = [c for c in ("total_fwd_packets", "total_bwd_packets", "total_fwd_bytes", "total_bwd_bytes",
                        "flow_duration", "flow_packets_per_s", "flow_bytes_per_s") if c in view.columns]
if num_cols:
    st.markdown("##### Packet and byte statistics")
    desc = view[num_cols].apply(pd.to_numeric, errors="coerce").describe().T[["count", "mean", "std", "min", "50%", "max"]]
    st.dataframe(desc.round(2), width="stretch")

# ------------------------------------------------------------------ indicators
st.markdown("##### Suspicious traffic indicators")
st.caption("Simple statistical checks computed from the records shown. They are hints for investigation, not model predictions.")
ind = st.columns(3)
with ind[0]:
    with ui.card("ind_scan"):
        if {"src_ip", "dst_port"} <= set(view.columns):
            per = view.groupby("src_ip")["dst_port"].nunique().sort_values(ascending=False)
            scanners = per[per >= 50]
            st.metric("Possible port scanners", f"{len(scanners):,}")
            st.caption("Sources that contacted 50 or more distinct destination ports.")
            if len(scanners):
                st.dataframe(scanners.head(5).rename("Distinct ports").reset_index().rename(columns={"src_ip": "Source IP"}),
                             hide_index=True, width="stretch")
        else:
            st.metric("Possible port scanners", "n/a")
            st.caption("Needs source IP and destination port columns.")
with ind[1]:
    with ui.card("ind_rate"):
        if "flow_packets_per_s" in view.columns:
            r = num("flow_packets_per_s").dropna()
            thr = r.quantile(0.99) if len(r) else 0
            st.metric("Very high packet-rate flows", f"{int((r > thr).sum()):,}")
            st.caption(f"Flows above the 99th percentile ({thr:,.0f} packets/s).")
        else:
            st.metric("Very high packet-rate flows", "n/a")
            st.caption("Needs a flow packets-per-second column.")
with ind[2]:
    with ui.card("ind_oneway"):
        if {"total_fwd_packets", "total_bwd_packets"} <= set(view.columns):
            one = (num("total_bwd_packets") == 0) & (num("total_fwd_packets") >= 20)
            st.metric("One-way bursts", f"{int(one.sum()):,}")
            st.caption("Flows with 20+ forward packets and no reply (flood-like).")
        else:
            st.metric("One-way bursts", "n/a")
            st.caption("Needs forward and backward packet columns.")
