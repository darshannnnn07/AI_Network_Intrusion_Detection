"""Page 6 - System information and about."""
import platform
import sys
from importlib import metadata

import streamlit as st

from src import state, ui
from src.config import APP_NAME, PROJECT_INFO

state.ensure_state()
ss = st.session_state

ui.page_header("System information", "About this project, how it works and what it can and cannot do")

c1, c2 = st.columns([3, 2])
with c1:
    with ui.card("about"):
        ui.card_title(APP_NAME)
        ui.html_block("""
        <div class="kv" style="margin-top:8px">
          <div class="k">Project domain</div><div class="v" style="font-family:var(--body)">Computer Networks, Cybersecurity and Machine Learning</div>
          <div class="k">Objective</div><div class="v" style="font-family:var(--body)">To demonstrate how machine learning can analyze network traffic features and help identify potentially malicious network activity.</div>
        </div>""")
with c2:
    with ui.card("team"):
        ui.card_title("Project details")
        rows = "".join(f'<div class="k">{ui.esc(k)}</div><div class="v" style="font-family:var(--body)">{ui.esc(v)}</div>'
                       for k, v in PROJECT_INFO.items())
        ui.html_block(f'<div class="kv" style="margin-top:8px">{rows}</div>')
        st.caption("Edit PROJECT_INFO in src/config.py to show your own details.")

st.markdown("##### System workflow")
steps = [
    ("Collect", "Network traffic data is collected or uploaded as CSV flow records."),
    ("Validate", "Columns are standardised, types checked and missing values handled."),
    ("Extract", "Relevant traffic features are selected (ports, packets, bytes, rates)."),
    ("Analyze", "A trained scikit-learn model scores each flow."),
    ("Classify", "Each flow is labelled Normal or Suspicious, with an attack category."),
    ("Present", "Potential threats appear on the dashboard, alerts and explorer pages."),
    ("Review", "Security staff inspect alerts and export the results as CSV."),
]
ui.html_block('<div class="flow">' + "".join(
    f'<div class="flow-step"><div class="n">Step {i + 1}</div><div class="t">{ui.esc(t)}</div><div class="d">{ui.esc(d)}</div></div>'
    for i, (t, d) in enumerate(steps)) + "</div>")

st.write("")
st.markdown("##### Key technologies")
def ver(pkg):
    try:
        return metadata.version(pkg)
    except metadata.PackageNotFoundError:
        return "?"
techs = [("Python", platform.python_version()), ("Streamlit", ver("streamlit")), ("Pandas", ver("pandas")),
         ("NumPy", ver("numpy")), ("Scikit-learn", ver("scikit-learn")), ("Plotly", ver("plotly"))]
ui.html_block('<div class="tech">' + "".join(f'<div class="tech-chip">{ui.esc(n)}<span>{ui.esc(v)}</span></div>' for n, v in techs) + "</div>")

st.write("")
c3, c4 = st.columns(2)
with c3:
    with ui.card("sys_model"):
        ui.card_title("Detection model")
        m = ss.model
        st.markdown(f"- Algorithm: **{m.model_type}**\n- Trained on: {m.source}\n- Classes: {', '.join(m.classes)}\n"
                    f"- Features: {len(m.feature_columns)}\n- Synthetic training data: **{'yes' if m.synthetic else 'no'}**")
with c4:
    with ui.card("sys_env"):
        ui.card_title("Environment")
        st.markdown(f"- Operating system: {platform.system()} {platform.release()}\n- Python: {sys.version.split()[0]}\n"
                    f"- Data on dashboard: {ss.source_label}\n- Live capture: not available in this version")

st.write("")
ui.note("Disclaimer: this application is an educational prototype. Its detections depend entirely on the data and "
        "model available to it. The built-in demo data and model are synthetic, so results must not be treated as "
        "evidence of real-world security performance, and the tool must not be relied on to protect a real network.", "warn")
