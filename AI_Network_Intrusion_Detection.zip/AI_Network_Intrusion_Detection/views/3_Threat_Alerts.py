"""Page 3 - Threat intelligence and alerts."""
import numpy as np
import pandas as pd
import streamlit as st

from src import alerts as al
from src import charts, state, ui
from src.config import CATEGORY_COLORS, COLORS

state.ensure_state()
ss = st.session_state
alerts_all = ss.alerts_df.copy()

ui.page_header("Threat intelligence and alerts", "Review, filter and export detections")

if ss.data_source in ("demo", "stream"):
    ui.note("These are synthetic demonstration alerts generated from simulated traffic. They do not come from a "
            "real network.", "warn")
else:
    ui.note(f"Alerts are derived from model predictions on your uploaded dataset ({ss.source_label}). "
            "Severity and status values are demonstration policies, not analyst decisions.")

if alerts_all.empty:
    st.info("No alerts yet. Run the demo simulation on the Security Overview page or analyze a dataset.")
    st.stop()

# apply status changes made in this session
alerts_all["status"] = alerts_all.apply(lambda r: ss.alert_status.get(r["alert_id"], r["status"]), axis=1)

# ---------------------------------------------------------------- filters
with ui.card("filters"):
    ui.card_title("Filters")
    f1, f2, f3, f4 = st.columns(4)
    sev = f1.multiselect("Severity", al.SEVERITY_ORDER, key="f_sev")
    cat = f2.multiselect("Attack category", sorted(alerts_all["category"].unique()), key="f_cat")
    proto = f3.multiselect("Protocol", sorted(alerts_all["protocol"].unique()), key="f_proto")
    status = f4.multiselect("Alert status", al.STATUS_VALUES, key="f_status")
    s1, s2 = st.columns([2, 1])
    ip_q = s1.text_input("Source IP contains", key="f_ip", placeholder="e.g. 203.0.113")
    min_risk = s2.slider("Minimum risk score", 0, 100, 0, key="f_risk")

flt = alerts_all
if sev:
    flt = flt[flt["severity"].isin(sev)]
if cat:
    flt = flt[flt["category"].isin(cat)]
if proto:
    flt = flt[flt["protocol"].isin(proto)]
if status:
    flt = flt[flt["status"].isin(status)]
if ip_q.strip():
    flt = flt[flt["src_ip"].str.contains(ip_q.strip(), regex=False, case=False)]
flt = flt[flt["risk_score"] >= min_risk]

# ---------------------------------------------------------------- summary
counts = flt["severity"].value_counts()
chips = "".join(f'<span class="badge {ui.SEV_CLASS[s]}">{s}: {int(counts.get(s, 0)):,}</span> '
                for s in al.SEVERITY_ORDER)
ui.html_block(f'<div style="margin:6px 0 14px">{chips}<span class="stamp" style="margin-left:8px">{len(flt):,} of {len(alerts_all):,} alerts match</span></div>')

# ---------------------------------------------------------------- table
table = flt.rename(columns={"alert_id": "Alert ID", "timestamp": "Timestamp", "src_ip": "Source IP",
                            "dst_ip": "Destination IP", "protocol": "Protocol", "dst_port": "Dest. port",
                            "category": "Attack category", "risk_score": "Risk score", "severity": "Severity",
                            "status": "Status"}).drop(columns=["flow_idx"])
table["Timestamp"] = table["Timestamp"].astype(str).str.slice(0, 19).replace("NaT", "N/A")
if flt.empty:
    st.info("No alerts match the current filters.")
else:
    event = st.dataframe(ui.style_table(table, ["Severity", "Status"], ["Risk score"], max_rows=1000),
                         hide_index=True, width="stretch", height=380, key="alerts_tbl",
                         on_select="rerun", selection_mode="single-row")
    st.caption("Select a row to inspect it. The table shows up to 1,000 alerts; the export contains all filtered alerts.")
    export = flt.drop(columns=["flow_idx"]).copy()
    export["data_source"] = "synthetic demonstration" if ss.data_source in ("demo", "stream") else ss.source_label
    st.download_button("Export filtered alerts (CSV)", export.to_csv(index=False).encode("utf-8"),
                       file_name="filtered_alerts.csv", mime="text/csv", key="alerts_dl")

    # ------------------------------------------------------------ detail
    rows = event.selection.rows if event is not None and event.selection else []
    ids = flt["alert_id"].tolist()
    if rows and rows[0] < len(ids):
        chosen = ids[rows[0]]
    else:
        chosen = st.selectbox("Or choose an alert to inspect", ids[:1000], key="alert_pick")
    a = flt[flt["alert_id"] == chosen].iloc[0]

    st.markdown("##### Alert details")
    d1, d2 = st.columns([1, 1])
    with d1:
        with ui.card("detail_l"):
            ui.html_block(f"""
            <div class="feed-title" style="margin-bottom:10px">{ui.esc(a['alert_id'])} {ui.severity_badge(a['severity'])}
              {ui.badge(a['status'], 'b-info')}</div>
            <div class="kv">
              <div class="k">Category</div><div class="v">{ui.esc(a['category'])}</div>
              <div class="k">Risk score</div><div class="v">{a['risk_score']:.1f} / 100</div>
              <div class="k">Timestamp</div><div class="v">{ui.esc(str(a['timestamp'])[:19])}</div>
              <div class="k">Source IP</div><div class="v">{ui.esc(a['src_ip'])}</div>
              <div class="k">Destination IP</div><div class="v">{ui.esc(a['dst_ip'])}</div>
              <div class="k">Protocol / port</div><div class="v">{ui.esc(a['protocol'])} / {ui.esc(int(a['dst_port']) if pd.notna(a['dst_port']) else 'N/A')}</div>
            </div>""")
            ui.note("Recommended action: " + al.recommended_action(a["category"]), "warn" if a["severity"] != "Informational" else "ok")
            current = a["status"]
            new = st.selectbox("Update status", al.STATUS_VALUES, index=al.STATUS_VALUES.index(current), key=f"st_{chosen}")
            if st.button("Save status", key=f"save_{chosen}"):
                ss.alert_status[chosen] = new
                st.rerun()
    with d2:
        with ui.card("detail_r"):
            ui.card_title("Associated traffic details", "Flow record behind this alert")
            flow = ss.dashboard_df.loc[a["flow_idx"]]
            show_cols = [c for c in flow.index if c not in ("is_suspicious", "traffic_class")][:24]
            st.dataframe(pd.DataFrame({"Field": show_cols, "Value": [str(flow[c]) for c in show_cols]}),
                         hide_index=True, width="stretch", height=330)

# ---------------------------------------------------------------- intelligence summaries
st.markdown("##### Threat summary")
t1, t2 = st.columns(2)
susp = flt[flt["category"] != "Normal Traffic"]
with t1:
    with ui.card("top_src"):
        ui.show(charts.top_bar(susp["src_ip"].value_counts(), "Top sources by alert count", COLORS["red"],
                               xlabel="Alerts"), "al_top_src")
with t2:
    with ui.card("cat_mix"):
        ui.show(charts.category_bar(susp["category"].value_counts(), "Alerts by attack category", 300), "al_cat")
