"""Evaluation helpers built on scikit-learn metrics (no Streamlit code here).

"Positive" always means Suspicious (any non-benign class).
"""
from __future__ import annotations

import numpy as np
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_recall_fscore_support,
                             precision_score, recall_score, roc_auc_score, roc_curve)


def binary_metrics(y_true_bin, y_pred_bin, scores=None) -> dict:
    y_true_bin = np.asarray(y_true_bin).astype(int)
    y_pred_bin = np.asarray(y_pred_bin).astype(int)
    n = int(len(y_true_bin))
    cm = confusion_matrix(y_true_bin, y_pred_bin, labels=[0, 1])
    tn, fp, fn, tp = (int(v) for v in cm.ravel())
    negatives, positives = tn + fp, tp + fn
    auc = None
    if scores is not None and positives > 0 and negatives > 0:
        try:
            auc = float(roc_auc_score(y_true_bin, scores))
        except ValueError:
            auc = None
    return {
        "n": n,
        "accuracy": float(accuracy_score(y_true_bin, y_pred_bin)) if n else None,
        "precision": float(precision_score(y_true_bin, y_pred_bin, zero_division=0)),
        "recall": float(recall_score(y_true_bin, y_pred_bin, zero_division=0)),
        "f1": float(f1_score(y_true_bin, y_pred_bin, zero_division=0)),
        "fpr": (fp / negatives) if negatives else None,
        "auc": auc,
        "tn": tn, "fp": fp, "fn": fn, "tp": tp,
        "positives": positives, "negatives": negatives,
    }


def class_report(y_true, y_pred, labels) -> list:
    p, r, f, s = precision_recall_fscore_support(y_true, y_pred, labels=labels, zero_division=0)
    rows = [{"class": str(l), "precision": float(a), "recall": float(b), "f1": float(c), "support": int(d)}
            for l, a, b, c, d in zip(labels, p, r, f, s)]
    total = int(sum(s))
    if total:
        w = np.asarray(s) / total
        rows.append({"class": "macro avg", "precision": float(np.mean(p)), "recall": float(np.mean(r)),
                     "f1": float(np.mean(f)), "support": total})
        rows.append({"class": "weighted avg", "precision": float(np.sum(p * w)), "recall": float(np.sum(r * w)),
                     "f1": float(np.sum(f * w)), "support": total})
    return rows


def multiclass_confusion(y_true, y_pred, labels) -> list:
    return confusion_matrix(y_true, y_pred, labels=labels).tolist()


def roc_points(y_true_bin, scores, max_points: int = 200):
    y_true_bin = np.asarray(y_true_bin).astype(int)
    if y_true_bin.min() == y_true_bin.max():
        return None
    fpr, tpr, _ = roc_curve(y_true_bin, scores)
    if len(fpr) > max_points:
        idx = np.linspace(0, len(fpr) - 1, max_points).astype(int)
        fpr, tpr = fpr[idx], tpr[idx]
    return {"fpr": [float(x) for x in fpr], "tpr": [float(x) for x in tpr]}


def majority_baseline(y_true_bin) -> dict:
    """What a useless 'always Normal' detector would score."""
    y = np.asarray(y_true_bin).astype(int)
    if len(y) == 0:
        return {"always_normal_accuracy": None, "attack_share": None}
    return {"always_normal_accuracy": float((y == 0).mean()), "attack_share": float((y == 1).mean())}


def evaluate_split(y_true_labels, pred_labels, is_susp, risk, benign_label, class_labels) -> dict:
    """Full evaluation payload for one data split."""
    y_true_labels = np.asarray(y_true_labels).astype(str)
    pred_labels = np.asarray(pred_labels).astype(str)
    y_bin = (y_true_labels != benign_label).astype(int)
    p_bin = np.asarray(is_susp).astype(int)
    out = {
        "binary": binary_metrics(y_bin, p_bin, scores=np.asarray(risk)),
        "baseline": majority_baseline(y_bin),
        "roc": roc_points(y_bin, np.asarray(risk)),
        "class_labels": list(class_labels),
        "multiclass_cm": multiclass_confusion(y_true_labels, pred_labels, class_labels),
        "report": class_report(y_true_labels, pred_labels, class_labels),
        "class_counts": {str(k): int(v) for k, v in zip(*np.unique(y_true_labels, return_counts=True))},
    }
    return out
