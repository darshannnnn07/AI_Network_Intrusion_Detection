"""Central configuration: names, colours and project metadata.

Edit PROJECT_INFO below to put your own name / college details on the
System Information page.
"""
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parent.parent
ASSETS_DIR = ROOT_DIR / "assets"
MODELS_DIR = ROOT_DIR / "models"
DATA_DIR = ROOT_DIR / "data"

APP_NAME = "AI-Based Network Intrusion Detection System"
APP_SHORT = "AI-NIDS"
SUBTITLE = "Intelligent Network Threat Monitoring"

# Shown on the System Information page. Replace with your own details.
PROJECT_INFO = {
    "Student": "Your Name",
    "Programme": "BTech Computer Science Engineering",
    "Subject": "Computer Networks (mini-project)",
    "Institute": "Your College Name",
    "Guide": "Faculty Guide Name",
}

COLORS = {
    "bg": "#060A13",
    "surface": "#0C1322",
    "surface2": "#111B30",
    "border": "#1D2A45",
    "text": "#E8EEF9",
    "muted": "#8B98B5",
    "green": "#22E3A0",
    "cyan": "#22D3EE",
    "amber": "#F59E0B",
    "orange": "#FB923C",
    "red": "#EF4444",
    "violet": "#A78BFA",
    "slate": "#64748B",
}

SEVERITY_COLORS = {
    "Critical": COLORS["red"],
    "High": COLORS["orange"],
    "Medium": COLORS["amber"],
    "Low": COLORS["cyan"],
    "Informational": COLORS["slate"],
}

CATEGORY_COLORS = {
    "Normal Traffic": COLORS["green"],
    "DoS / DDoS": COLORS["red"],
    "Port Scanning": COLORS["cyan"],
    "Brute-Force Attempts": COLORS["orange"],
    "Botnet Activity": COLORS["violet"],
    "Suspicious Traffic": COLORS["amber"],
}

MAX_UPLOAD_ROWS = 500_000      # rows read from an uploaded CSV
MAX_SCORING_ROWS = 200_000     # rows scored in one analysis run
MAX_TRAINING_ROWS = 100_000    # rows used when training a model
