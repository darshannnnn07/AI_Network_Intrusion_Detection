"""Synthetic network-flow generator used for Demo Mode.

EVERYTHING produced here is synthetic. IP addresses come from the reserved
documentation / private ranges (RFC 5737, RFC 1918), so none of them refer to
real hosts. Results measured on this data say nothing about real-world
security performance.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

NORMAL_LABEL = "Normal Traffic"
ATTACK_CATEGORIES = ["DoS / DDoS", "Port Scanning", "Brute-Force Attempts", "Botnet Activity"]

FEATURE_COLUMNS = [
    "protocol", "src_port", "dst_port", "flow_duration",
    "total_fwd_packets", "total_bwd_packets", "total_fwd_bytes", "total_bwd_bytes",
    "pkt_len_mean", "pkt_len_std", "flow_packets_per_s", "flow_bytes_per_s",
]
FLOW_COLUMNS = ["timestamp", "src_ip", "dst_ip"] + FEATURE_COLUMNS + ["label"]

INTERNAL_CLIENTS = [f"192.168.1.{i}" for i in range(20, 120)]
INTERNAL_SERVERS = [f"10.0.0.{i}" for i in range(10, 30)]
INTERNET_SERVERS = [f"192.0.2.{i}" for i in range(1, 120)]
ATTACKER_POOL = [f"203.0.113.{i}" for i in range(1, 255)] + [f"198.51.100.{i}" for i in range(1, 255)]

# Example values for the manual-analysis form (made up, for demonstration).
PRESETS = {
    "Normal web session": dict(
        protocol="TCP", src_port=52344, dst_port=443, flow_duration=950.0,
        total_fwd_packets=11, total_bwd_packets=13, total_fwd_bytes=3100, total_bwd_bytes=7400,
        pkt_len_mean=437.0, pkt_len_std=380.0,
    ),
    "SYN flood burst": dict(
        protocol="TCP", src_port=31337, dst_port=80, flow_duration=55.0,
        total_fwd_packets=420, total_bwd_packets=0, total_fwd_bytes=25200, total_bwd_bytes=0,
        pkt_len_mean=60.0, pkt_len_std=4.0,
    ),
    "Port scan probe": dict(
        protocol="TCP", src_port=44321, dst_port=8731, flow_duration=7.0,
        total_fwd_packets=2, total_bwd_packets=0, total_fwd_bytes=96, total_bwd_bytes=0,
        pkt_len_mean=48.0, pkt_len_std=3.0,
    ),
    "SSH brute-force attempt": dict(
        protocol="TCP", src_port=50122, dst_port=22, flow_duration=2300.0,
        total_fwd_packets=14, total_bwd_packets=13, total_fwd_bytes=1400, total_bwd_bytes=1900,
        pkt_len_mean=122.0, pkt_len_std=70.0,
    ),
}


def _ln(rng, median, sigma, n):
    return rng.lognormal(np.log(median), sigma, n)


def _pick(rng, pool, n):
    return rng.choice(np.array(pool), n)


def _normal(rng, n):
    proto = rng.choice(["TCP", "UDP", "ICMP"], n, p=[0.72, 0.24, 0.04])
    ports = np.array([443, 80, 53, 22, 123, 8080, 3389, 445, 993, 25, 5228])
    p = np.array([0.38, 0.20, 0.14, 0.04, 0.04, 0.05, 0.03, 0.04, 0.03, 0.02, 0.03])
    dst_port = rng.choice(ports, n, p=p / p.sum())
    udp = proto == "UDP"
    dst_port[udp] = rng.choice([53, 123, 443, 5353], udp.sum())
    dst_port[proto == "ICMP"] = 0
    fwd = np.clip(_ln(rng, 10, 0.9, n), 1, 3000).round()
    bwd = np.clip(_ln(rng, 12, 0.9, n), 0, 3000).round()
    fwd_b = fwd * np.clip(_ln(rng, 260, 0.7, n), 40, 1460)
    bwd_b = bwd * np.clip(_ln(rng, 520, 0.8, n), 40, 1460)
    mean = (fwd_b + bwd_b) / np.maximum(fwd + bwd, 1)
    src = _pick(rng, INTERNAL_CLIENTS, n)
    dst = np.where(rng.random(n) < 0.6, _pick(rng, INTERNET_SERVERS, n), _pick(rng, INTERNAL_SERVERS, n))
    return dict(src_ip=src, dst_ip=dst, protocol=proto, src_port=rng.integers(49152, 65535, n),
                dst_port=dst_port, duration=_ln(rng, 900, 1.5, n), fwd=fwd, bwd=bwd,
                fwd_b=fwd_b, bwd_b=bwd_b, std=mean * rng.uniform(0.6, 1.4, n))


def _bursty_legit(rng, n):
    """Large downloads / backups: legitimate but heavy (overlaps with floods)."""
    d = _normal(rng, n)
    d["protocol"] = np.array(["TCP"] * n)
    d["dst_port"] = rng.choice([443, 80, 445], n)
    d["fwd"] = np.clip(_ln(rng, 350, 0.8, n), 60, 3000).round()
    d["bwd"] = np.clip(_ln(rng, 900, 0.8, n), 60, 5000).round()
    d["fwd_b"] = d["fwd"] * rng.uniform(60, 200, n)
    d["bwd_b"] = d["bwd"] * rng.uniform(900, 1450, n)
    d["duration"] = _ln(rng, 6000, 0.7, n)
    d["std"] = rng.uniform(300, 650, n)
    return d


def _dos(rng, n):
    proto = rng.choice(["TCP", "UDP", "ICMP"], n, p=[0.55, 0.35, 0.10])
    dst_port = np.where(proto == "TCP", rng.choice([80, 443], n), rng.choice([53, 123, 19, 1900], n))
    dst_port[proto == "ICMP"] = 0
    mean = np.where(proto == "TCP", rng.uniform(40, 80, n), rng.uniform(400, 1400, n))
    fwd = np.clip(_ln(rng, 350, 0.7, n), 20, 5000).round()
    bwd = rng.poisson(1.0, n)
    victims = INTERNAL_SERVERS[:3]
    return dict(src_ip=_pick(rng, ATTACKER_POOL, n), dst_ip=_pick(rng, victims, n), protocol=proto,
                src_port=rng.integers(1024, 65535, n), dst_port=dst_port,
                duration=_ln(rng, 60, 0.9, n), fwd=fwd, bwd=bwd.astype(float),
                fwd_b=fwd * mean, bwd_b=bwd * 40.0, std=mean * rng.uniform(0.02, 0.15, n))


def _scan(rng, n):
    scanners = ATTACKER_POOL[:4]
    fwd = rng.integers(1, 4, n).astype(float)
    bwd = rng.poisson(0.3, n).astype(float)
    return dict(src_ip=_pick(rng, scanners, n), dst_ip=_pick(rng, INTERNAL_SERVERS[:2], n),
                protocol=rng.choice(["TCP", "UDP"], n, p=[0.92, 0.08]),
                src_port=rng.choice([44321, 51515, 40000, 58213], n),
                dst_port=rng.integers(1, 65535, n), duration=_ln(rng, 8, 0.9, n), fwd=fwd, bwd=bwd,
                fwd_b=fwd * rng.uniform(40, 66, n), bwd_b=bwd * rng.uniform(40, 60, n),
                std=rng.uniform(0, 12, n))


def _brute(rng, n):
    fwd = np.clip(_ln(rng, 14, 0.35, n), 4, 60).round()
    bwd = np.clip(_ln(rng, 13, 0.35, n), 4, 60).round()
    return dict(src_ip=_pick(rng, ATTACKER_POOL[300:306], n), dst_ip=_pick(rng, INTERNAL_SERVERS[3:8], n),
                protocol=np.array(["TCP"] * n),
                src_port=rng.integers(49152, 65535, n),
                dst_port=rng.choice([22, 3389, 21, 23, 445], n, p=[0.45, 0.25, 0.12, 0.08, 0.10]),
                duration=_ln(rng, 2200, 0.45, n), fwd=fwd, bwd=bwd,
                fwd_b=fwd * rng.uniform(70, 130, n), bwd_b=bwd * rng.uniform(60, 200, n),
                std=rng.uniform(40, 110, n))


def _botnet(rng, n):
    fwd = np.clip(_ln(rng, 5, 0.4, n), 2, 30).round()
    bwd = np.clip(_ln(rng, 5, 0.4, n), 1, 30).round()
    c2 = ATTACKER_POOL[400:405]
    return dict(src_ip=_pick(rng, INTERNAL_CLIENTS[:6], n), dst_ip=_pick(rng, c2, n),
                protocol=rng.choice(["TCP", "UDP"], n, p=[0.7, 0.3]),
                src_port=rng.integers(49152, 65535, n),
                dst_port=rng.choice([6667, 4444, 8080, 1337, 443, 8443, 53], n,
                                    p=[0.2, 0.2, 0.15, 0.15, 0.15, 0.1, 0.05]),
                duration=_ln(rng, 1200, 0.9, n), fwd=fwd, bwd=bwd,
                fwd_b=fwd * rng.uniform(80, 200, n), bwd_b=bwd * rng.uniform(100, 350, n),
                std=rng.uniform(30, 90, n))


_PROFILES = {
    NORMAL_LABEL: _normal,
    "DoS / DDoS": _dos,
    "Port Scanning": _scan,
    "Brute-Force Attempts": _brute,
    "Botnet Activity": _botnet,
}


def _timestamps(rng, n, start, minutes, bursty):
    total = minutes * 60.0
    if bursty:
        k = int(rng.integers(1, 4))
        centers = rng.uniform(0.1, 0.9, k) * total
        off = centers[rng.integers(0, k, n)] + rng.normal(0, total * 0.03, n)
        off = np.clip(off, 0, total)
    else:
        off = rng.uniform(0, total, n)
    return pd.Timestamp(start) + pd.to_timedelta(off, unit="s")


def _frame(d, ts, label):
    n = len(d["fwd"])
    dur_s = np.maximum(d["duration"], 1.0) / 1000.0
    tot_p = d["fwd"] + d["bwd"]
    tot_b = d["fwd_b"] + d["bwd_b"]
    return pd.DataFrame({
        "timestamp": ts,
        "src_ip": d["src_ip"],
        "dst_ip": d["dst_ip"],
        "protocol": d["protocol"],
        "src_port": np.asarray(d["src_port"]).astype(int),
        "dst_port": np.asarray(d["dst_port"]).astype(int),
        "flow_duration": np.round(d["duration"], 3),
        "total_fwd_packets": d["fwd"].astype(int),
        "total_bwd_packets": d["bwd"].astype(int),
        "total_fwd_bytes": np.round(d["fwd_b"]).astype(int),
        "total_bwd_bytes": np.round(d["bwd_b"]).astype(int),
        "pkt_len_mean": np.round(tot_b / np.maximum(tot_p, 1), 2),
        "pkt_len_std": np.round(d["std"], 2),
        "flow_packets_per_s": np.round(tot_p / dur_s, 2),
        "flow_bytes_per_s": np.round(tot_b / dur_s, 2),
        "label": [label] * n if isinstance(label, str) else label,
    })


def generate_flows(n: int = 4000, seed: int = 42, attack_ratio: float = 0.22,
                   start=None, minutes: float = 60.0, evasive: float = 0.10) -> pd.DataFrame:
    """Generate ``n`` synthetic labelled flows.

    ``evasive`` is the share of attack flows that look like normal traffic
    (stealthy attacks) and ~3 % of normal flows are heavy legitimate transfers,
    so the classes overlap and metrics are not trivially perfect.
    """
    rng = np.random.default_rng(seed)
    n = max(int(n), 10)
    attack_ratio = float(np.clip(attack_ratio, 0.01, 0.9))
    if start is None:
        start = (pd.Timestamp.now().floor("s") - pd.Timedelta(minutes=minutes))
    n_attack = int(round(n * attack_ratio))
    n_normal = n - n_attack
    split = rng.multinomial(n_attack, [0.35, 0.25, 0.20, 0.20])
    parts = []

    n_bursty = int(n_normal * 0.03)
    base = _frame(_normal(rng, n_normal - n_bursty), _timestamps(rng, n_normal - n_bursty, start, minutes, False), NORMAL_LABEL)
    parts.append(base)
    if n_bursty:
        parts.append(_frame(_bursty_legit(rng, n_bursty), _timestamps(rng, n_bursty, start, minutes, False), NORMAL_LABEL))

    for cat, cnt in zip(ATTACK_CATEGORIES, split):
        if cnt == 0:
            continue
        n_ev = int(cnt * evasive)
        if n_ev:
            parts.append(_frame(_normal(rng, n_ev), _timestamps(rng, n_ev, start, minutes, True), cat))
        n_main = cnt - n_ev
        if n_main:
            parts.append(_frame(_PROFILES[cat](rng, n_main), _timestamps(rng, n_main, start, minutes, True), cat))

    df = pd.concat(parts, ignore_index=True).sort_values("timestamp").reset_index(drop=True)
    return df[FLOW_COLUMNS]


def generate_training_set(n: int = 6000, seed: int = 7) -> pd.DataFrame:
    return generate_flows(n=n, seed=seed, attack_ratio=0.35)


def generate_stream_batch(n: int, seed: int, now=None, attack_ratio: float = 0.2) -> pd.DataFrame:
    """A small batch of events stamped around 'now' for the live-style simulation."""
    now = pd.Timestamp.now() if now is None else pd.Timestamp(now)
    return generate_flows(n=n, seed=seed, attack_ratio=attack_ratio,
                          start=now - pd.Timedelta(seconds=4), minutes=4 / 60)
