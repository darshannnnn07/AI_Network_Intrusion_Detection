"""Session-state management shared by all pages."""
from __future__ import annotations

from datetime import datetime

import numpy as np
import pandas as pd
import streamlit as st

from . import alerts as alerts_mod
from . import data_loader, demo_data
from . import detection_model as dm
from .config import MODELS_DIR
from .preprocessing import canonicalize

DEFAULT_MODEL_FILE = MODELS_DIR / "demo_random_forest.joblib"
LAST_MODEL_FILE = MODELS_DIR / "last_trained_model.joblib"
PRED_COLS = ["prediction", "is_suspicious", "risk_score", "confidence", "traffic_class"]
DEFAULT_SIM = {"n": 4000, "attack_ratio": 0.22, "seed": 42}


def now_str() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@st.cache_resource(show_spinner="Preparing the demonstration model...")
def load_default_model():
    """Load the saved demo model, or train it (about a second) and save it."""
    model = dm.load_model(DEFAULT_MODEL_FILE)
    if model is None:
        model = dm.train_default_demo_model()
        try:
            dm.save_model(model, DEFAULT_MODEL_FILE)
        except OSError:
            pass  # read-only folder: keep the in-memory model
    return model


@st.cache_data(show_spinner=False, max_entries=4)
def cached_parse(data: bytes):
    return data_loader.parse_csv_bytes(data)


def score_df(df: pd.DataFrame, model=None) -> pd.DataFrame:
    model = model or st.session_state.model
    base = df.drop(columns=[c for c in PRED_COLS if c in df.columns])
    pf = dm.predict_frame(model, base)
    out = base.join(pf)
    out["traffic_class"] = np.where(out["is_suspicious"], "Suspicious", "Normal")
    return out


def set_dashboard(scored: pd.DataFrame, kind: str, label: str) -> None:
    ss = st.session_state
    ss.dashboard_df = scored
    ss.alerts_df = alerts_mod.build_alerts(scored)
    ss.alert_status = {}
    ss.data_source = kind
    ss.source_label = label
    ss.last_updated = now_str()


def run_demo_simulation(n=None, attack_ratio=None, seed=None) -> None:
    ss = st.session_state
    p = ss.sim_params
    p["n"] = int(n if n is not None else p["n"])
    p["attack_ratio"] = float(attack_ratio if attack_ratio is not None else p["attack_ratio"])
    p["seed"] = int(seed if seed is not None else p["seed"])
    df = demo_data.generate_flows(n=p["n"], seed=p["seed"], attack_ratio=p["attack_ratio"])
    set_dashboard(score_df(df), "demo", "Synthetic demonstration data (simulated)")


def append_demo_events(n: int = 250) -> None:
    """Add a fresh batch of synthetic events on top of the current demo data."""
    ss = st.session_state
    if ss.data_source != "demo":
        run_demo_simulation()
        return
    ss.sim_params["seed"] += 1
    batch = demo_data.generate_flows(n=n, seed=ss.sim_params["seed"] + 1000,
                                     attack_ratio=ss.sim_params["attack_ratio"],
                                     start=ss.dashboard_df["timestamp"].max(), minutes=5)
    combined = pd.concat([ss.dashboard_df.drop(columns=[c for c in PRED_COLS if c in ss.dashboard_df.columns]),
                          batch], ignore_index=True)
    set_dashboard(score_df(combined), "demo", "Synthetic demonstration data (simulated)")


def reset_demo() -> None:
    ss = st.session_state
    ss.sim_params = dict(DEFAULT_SIM)
    ss.analysis = None
    ss.live_buffer = None
    run_demo_simulation()


def ensure_state() -> None:
    """Idempotent initialisation; safe to call at the top of every page."""
    ss = st.session_state
    if "initialized" in ss:
        return
    try:
        ss.model = load_default_model()
    except Exception as exc:  # pragma: no cover - defensive
        st.error(f"The demonstration model could not be prepared: {exc}")
        st.stop()
    ss.sim_params = dict(DEFAULT_SIM)
    ss.analysis = None
    ss.live_buffer = None
    ss.live_running = False
    ss.live_total = 0
    ss.live_threats = 0
    ss.trained_result = None
    run_demo_simulation()
    ss.initialized = True


def parse_upload(uploaded):
    """Parse an st.file_uploader file. Returns (df, notes) or raises DataError."""
    return cached_parse(uploaded.getvalue())


def canonical_upload(uploaded):
    df, notes = parse_upload(uploaded)
    clean, renamed = canonicalize(df)
    return clean, renamed, notes
