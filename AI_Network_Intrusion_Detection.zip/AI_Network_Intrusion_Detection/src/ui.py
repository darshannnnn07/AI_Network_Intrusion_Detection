"""Shared Streamlit UI helpers: CSS, header, KPI cards, badges, styled tables, sidebar."""
from __future__ import annotations

import html

import pandas as pd
import streamlit as st

from . import state
from .config import APP_NAME, APP_SHORT, ASSETS_DIR, COLORS, SUBTITLE

ICONS = {
    "packets": '<path d="M21 8l-9-5-9 5 9 5 9-5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>',
    "flows": '<circle cx="6" cy="6" r="2.5"/><circle cx="18" cy="6" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="M8 7.5l3 8M16 7.5l-3 8M8.5 6h7"/>',
    "threat": '<path d="M12 3l9 16H3L12 3z"/><path d="M12 10v4M12 17h.01"/>',
    "normal": '<path d="M12 3l8 3v6c0 4.5-3.2 8-8 9-4.8-1-8-4.5-8-9V6l8-3z"/><path d="M8.5 12l2.5 2.5 4.5-5"/>',
    "alert": '<path d="M6 8a6 6 0 1112 0c0 7 3 8 3 8H3s3-1 3-8z"/><path d="M10 20a2 2 0 004 0"/>',
}


def inject_css() -> None:
    try:
        css = (ASSETS_DIR / "style.css").read_text(encoding="utf-8")
    except OSError:
        css = ""
    st.markdown(f"<style>{css}</style>", unsafe_allow_html=True)


def esc(x) -> str:
    return html.escape(str(x), quote=True)


def _h(s: str) -> str:
    """Collapse HTML to one line so Markdown never treats it as a code block."""
    return "".join(line.strip() for line in s.splitlines())


def html_block(s: str) -> None:
    st.markdown(_h(s), unsafe_allow_html=True)


def card(key: str):
    """A bordered card container (styled through the st-key-card-* CSS class)."""
    return st.container(key=f"card-{key}")


def card_title(title: str, sub: str = "") -> None:
    html_block(f'<div class="card-title">{esc(title)}</div>' + (f'<div class="card-sub">{esc(sub)}</div>' if sub else ""))


def page_header(title: str, subtitle: str, status: str | None = None) -> None:
    ss = st.session_state
    stamp = ss.get("last_updated", "")
    pill = ""
    if status:
        pill = f'<span class="pill"><span class="dot"></span>{esc(status)}</span>'
    html_block(f"""
    <div class="page-head">
      <div><h1 class="page-title">{esc(title)}</h1><div class="page-sub">{esc(subtitle)}</div></div>
      <div class="head-meta">{pill}<span class="stamp">Last updated {esc(stamp)}</span></div>
    </div>""")


def kpi(label: str, value: str, hint: str, icon: str, color: str) -> None:
    html_block(f"""
    <div class="kpi">
      <div class="kpi-top"><span class="kpi-label">{esc(label)}</span>
        <span class="kpi-icon" style="background:{color}22;border:1px solid {color}55">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="{color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">{ICONS[icon]}</svg>
        </span></div>
      <div class="kpi-value">{esc(value)}</div>
      <div class="kpi-hint">{esc(hint)}</div>
    </div>""")


SEV_CLASS = {"Critical": "b-critical", "High": "b-high", "Medium": "b-medium", "Low": "b-low", "Informational": "b-info"}


def badge(text: str, kind: str) -> str:
    return f'<span class="badge {kind}">{esc(text)}</span>'


def severity_badge(sev: str) -> str:
    return badge(sev, SEV_CLASS.get(sev, "b-info"))


def note(text: str, kind: str = "") -> None:
    html_block(f'<div class="note {kind}">{esc(text)}</div>')


def show(fig, key: str) -> None:
    st.plotly_chart(fig, width="stretch", theme=None, key=key,
                    config={"displaylogo": False, "modeBarButtonsToRemove": ["lasso2d", "select2d", "autoScale2d"]})


# ------------------------------------------------------------------ styled tables
_SEV_CELL = {
    "Critical": "background-color:rgba(239,68,68,.2);color:#FCA5A5;font-weight:600",
    "High": "background-color:rgba(251,146,60,.2);color:#FDBA74;font-weight:600",
    "Medium": "background-color:rgba(245,158,11,.2);color:#FCD34D;font-weight:600",
    "Low": "background-color:rgba(34,211,238,.16);color:#67E8F9;font-weight:600",
    "Informational": "background-color:rgba(100,116,139,.2);color:#A8B4CC",
    "Suspicious": "background-color:rgba(239,68,68,.2);color:#FCA5A5;font-weight:600",
    "Normal": "background-color:rgba(34,227,160,.16);color:#6EF2C0;font-weight:600",
    "Open": "color:#FCA5A5", "Investigating": "color:#FCD34D", "Resolved": "color:#6EF2C0",
    "False Positive": "color:#A8B4CC",
}


def _cell(v):
    return _SEV_CELL.get(str(v), "")


def _risk_cell(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return ""
    if v >= 80:
        return "color:#FCA5A5;font-weight:600"
    if v >= 50:
        return "color:#FCD34D;font-weight:600"
    return "color:#6EF2C0"


def style_table(df: pd.DataFrame, color_cols=(), risk_cols=(), max_rows: int = 1500):
    """Return a pandas Styler with colour-coded labels (truncated for speed)."""
    d = df.head(max_rows)
    sty = d.style.format(precision=2)
    cc = [c for c in color_cols if c in d.columns]
    rc = [c for c in risk_cols if c in d.columns]
    if cc:
        sty = sty.map(_cell, subset=cc)
    if rc:
        sty = sty.map(_risk_cell, subset=rc)
    one_dp = [c for c in list(rc) + ["confidence"] if c in d.columns]
    if one_dp:
        sty = sty.format("{:.1f}", subset=one_dp)
    return sty


# ------------------------------------------------------------------ sidebar
def render_sidebar(pages) -> None:
    ss = st.session_state
    with st.sidebar:
        html_block(f"""
        <div class="brand">
          <div class="brand-mark"><svg viewBox="0 0 48 48" width="26" height="26" fill="none" stroke="{COLORS['green']}" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M24 5l15 6v11c0 9.5-6.2 17.2-15 20-8.8-2.8-15-10.5-15-20V11l15-6z"/><path d="M15 24h5l3-6 4 11 3-5h4" stroke="{COLORS['cyan']}"/></svg></div>
          <div><div class="brand-name">{esc(APP_SHORT)}</div><div class="brand-sub">{esc(SUBTITLE)}</div></div>
        </div>""")
        for p in pages:
            st.page_link(p)
        model = ss.get("model")
        src = ss.get("source_label", "-")
        mtxt = model.short_name if model is not None else "No model loaded (rule-based only)"
        html_block(f"""
        <div class="side-card"><b>Detection model</b><br>{esc(mtxt)}</div>
        <div class="side-card"><b>Data on dashboard</b><br>{esc(src)}</div>
        <div class="side-card">Educational prototype. Demo traffic is synthetic and does not come from a real network.</div>
        """)
        if st.button("Reset to demo data", key="sb_reset", width="stretch"):
            state.reset_demo()
            st.rerun()
