"""Turn scored flows into an alert table, with severity and recommended actions."""
from __future__ import annotations

import numpy as np
import pandas as pd

SEVERITY_ORDER = ["Critical", "High", "Medium", "Low", "Informational"]
STATUS_VALUES = ["Open", "Investigating", "Resolved", "False Positive"]

# Demonstration severity policy: tier from risk score, then adjusted per category.
_TIERS = ["Low", "Medium", "High", "Critical"]
_ADJUST = {"dos": 0, "botnet": 0, "brute": -1, "scan": -2, "other": -1}

ACTIONS = {
    "dos": "Rate-limit or block the offending sources at the firewall, enable SYN-cookie / connection limits "
           "on the target, contact the upstream provider if the flood is volumetric, and keep the logs.",
    "scan": "Block or tar-pit the scanning source, confirm the firewall closes unused ports, review exposed "
            "services and check logs for follow-up exploitation attempts.",
    "brute": "Enforce account lockout and rate limiting, require multi-factor authentication, restrict SSH/RDP "
             "to a VPN or allow-list and review authentication logs for successful logins.",
    "botnet": "Isolate the internal host, review DNS and proxy logs for the command-and-control destination, "
              "block that destination and run an endpoint malware scan.",
    "other": "Investigate the flow in context, correlate it with other logs, and monitor the source before "
             "deciding whether to block it.",
    "normal": "No action required. Continue routine monitoring.",
}


def category_key(cat) -> str:
    c = str(cat).lower()
    if "normal" in c or "benign" in c:
        return "normal"
    if "dos" in c:
        return "dos"
    if "scan" in c or "probe" in c or "recon" in c:
        return "scan"
    if "brute" in c or "patator" in c:
        return "brute"
    if "bot" in c:
        return "botnet"
    return "other"


def recommended_action(category) -> str:
    return ACTIONS[category_key(category)]


def severity_for(score, category, suspicious) -> str:
    if not suspicious:
        return "Informational"
    tier = 3 if score >= 90 else 2 if score >= 75 else 1 if score >= 60 else 0
    tier = int(np.clip(tier + _ADJUST[category_key(category)], 0, 3))
    return _TIERS[tier]


def severity_series(scores, categories, suspicious) -> pd.Series:
    out = [severity_for(s, c, bool(x)) for s, c, x in zip(scores, categories, suspicious)]
    return pd.Series(out, index=getattr(scores, "index", None), dtype=object)


def _col(df, name, default):
    return df[name] if name in df.columns else pd.Series([default] * len(df), index=df.index)


def build_alerts(scored: pd.DataFrame, max_alerts: int = 5000, info_samples: int = 40, seed: int = 7) -> pd.DataFrame:
    """Alerts for suspicious flows plus a few informational 'normal' events."""
    cols = ["alert_id", "flow_idx", "timestamp", "src_ip", "dst_ip", "protocol", "dst_port",
            "category", "risk_score", "severity", "status"]
    if scored is None or len(scored) == 0 or "is_suspicious" not in scored.columns:
        return pd.DataFrame(columns=cols)
    susp = scored[scored["is_suspicious"]]
    if len(susp) > max_alerts:
        susp = susp.nlargest(max_alerts, "risk_score")
    benign = scored[~scored["is_suspicious"]]
    info = benign.sample(min(info_samples, len(benign)), random_state=seed) if len(benign) else benign
    sel = pd.concat([susp, info])
    if sel.empty:
        return pd.DataFrame(columns=cols)

    ts = pd.to_datetime(_col(sel, "timestamp", pd.NaT), errors="coerce")
    a = pd.DataFrame({
        "flow_idx": sel.index,
        "timestamp": ts.to_numpy(),
        "src_ip": _col(sel, "src_ip", "N/A").astype(str).to_numpy(),
        "dst_ip": _col(sel, "dst_ip", "N/A").astype(str).to_numpy(),
        "protocol": _col(sel, "protocol", "N/A").astype(str).to_numpy(),
        "dst_port": _col(sel, "dst_port", np.nan).to_numpy(),
        "category": sel["prediction"].astype(str).to_numpy(),
        "risk_score": sel["risk_score"].to_numpy(),
        "is_susp": sel["is_suspicious"].to_numpy(),
    })
    if a["timestamp"].notna().any():
        a = a.sort_values("timestamp", kind="stable")
    else:
        a = a.sort_values("risk_score", ascending=False, kind="stable")
    a = a.reset_index(drop=True)
    a["alert_id"] = [f"ALT-{i + 1:06d}" for i in range(len(a))]
    a["severity"] = severity_series(a["risk_score"], a["category"], a["is_susp"]).to_numpy()
    rng = np.random.default_rng(seed)
    status = rng.choice(STATUS_VALUES, len(a), p=[0.50, 0.20, 0.22, 0.08])
    a["status"] = np.where(a["is_susp"], status, "Resolved")
    a = a.drop(columns="is_susp")[cols]
    return a.iloc[::-1].reset_index(drop=True)  # newest first
