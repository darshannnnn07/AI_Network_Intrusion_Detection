"""CSV loading and light dataset inspection (no Streamlit code here)."""
from __future__ import annotations

import io

import pandas as pd

from .config import MAX_UPLOAD_ROWS
from .preprocessing import DataError


def parse_csv_bytes(data: bytes, max_rows: int = MAX_UPLOAD_ROWS):
    """Parse CSV bytes. Returns (df, notes). Raises DataError with a friendly message."""
    if not data or not data.strip():
        raise DataError("The file is empty.")
    notes = []
    df = None
    last_err = None
    for enc in ("utf-8-sig", "latin-1"):
        try:
            df = pd.read_csv(io.BytesIO(data), nrows=max_rows + 1, low_memory=False, encoding=enc)
            break
        except UnicodeDecodeError as exc:
            last_err = exc
        except pd.errors.EmptyDataError:
            raise DataError("The file has no columns or rows. Is it a real CSV file?")
        except pd.errors.ParserError as exc:
            raise DataError(f"The file could not be parsed as CSV ({exc}).")
    if df is None:
        raise DataError(f"The file could not be decoded as text ({last_err}). Upload a plain CSV file.")
    if df.shape[1] == 1 and any(d in str(df.columns[0]) for d in (";", "\t", "|")):
        try:
            df = pd.read_csv(io.BytesIO(data), sep=None, engine="python", nrows=max_rows + 1)
            notes.append("Delimiter was detected automatically.")
        except Exception:
            pass
    if df.shape[1] < 2:
        raise DataError("Only one column was found. Check that the file is comma-separated.")
    if len(df) == 0:
        raise DataError("The file contains a header but no data rows.")
    if len(df) > max_rows:
        df = df.iloc[:max_rows]
        notes.append(f"Only the first {max_rows:,} rows were loaded.")
    return df, notes


def dataset_overview(df: pd.DataFrame) -> dict:
    miss = df.isna().sum()
    miss = miss[miss > 0].sort_values(ascending=False)
    table = pd.DataFrame({"column": miss.index, "missing": miss.values,
                          "percent": (miss.values / max(len(df), 1) * 100).round(2)})
    return {"rows": len(df), "cols": df.shape[1], "missing_total": int(miss.sum()),
            "missing_table": table, "duplicates": int(df.duplicated().sum())}


def sample_csv_bytes(n: int = 1000, seed: int = 11) -> bytes:
    """A small synthetic labelled CSV users can download to try the upload features."""
    from .demo_data import generate_flows
    return generate_flows(n=n, seed=seed, attack_ratio=0.3).to_csv(index=False).encode("utf-8")
