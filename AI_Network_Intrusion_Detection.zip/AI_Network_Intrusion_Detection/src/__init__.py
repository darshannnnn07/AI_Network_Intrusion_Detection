"""AI-NIDS core package."""
