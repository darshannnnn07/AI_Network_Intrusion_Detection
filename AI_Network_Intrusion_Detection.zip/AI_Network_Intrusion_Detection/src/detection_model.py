"""Training, prediction and persistence for the intrusion-detection model.

The model is a scikit-learn Pipeline (preprocessing + classifier), so the exact
same preprocessing is applied at training and prediction time. The train/test
split happens BEFORE any fitting, so test data never influences imputation
statistics, scaling, encoding or the classifier.

Risk score = 100 x (1 - P(benign class)) as reported by the classifier. For a
Random Forest this is the share of trees voting for a non-benign class. It is a
model score, NOT a calibrated probability of an attack.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from . import demo_data, evaluation
from .preprocessing import (DEFAULT_FEATURES, DataError, build_preprocessor, is_benign_label,
                            prepare_features, split_feature_types)

BINARY_NORMAL = "Normal Traffic"
BINARY_SUSPICIOUS = "Suspicious Traffic"
SCHEMA_VERSION = 1
MODEL_TYPES = ["Random Forest", "Logistic Regression"]


class ModelError(RuntimeError):
    """Raised when a model cannot be trained or used."""


@dataclass
class ModelBundle:
    pipeline: Pipeline
    feature_columns: list
    numeric_columns: list
    categorical_columns: list
    classes: list
    benign_label: str
    model_type: str
    target_mode: str
    label_column: str
    source: str
    synthetic: bool
    trained_at: str
    n_train: int
    n_test: int
    reference_stats: dict = field(default_factory=dict)
    category_values: dict = field(default_factory=dict)
    importances: dict = field(default_factory=dict)
    evaluation: dict = field(default_factory=dict)
    schema_version: int = SCHEMA_VERSION

    @property
    def short_name(self) -> str:
        return f"{self.model_type} ({'synthetic data' if self.synthetic else 'user data'})"


# --------------------------------------------------------------------------- target
def prepare_target(series: pd.Series, mode: str):
    s = series.astype(str).str.strip()
    benign_mask = s.map(is_benign_label).astype(bool)
    if not benign_mask.any():
        raise DataError("No benign class found in the label column. Expected a value such as "
                        "'Normal', 'BENIGN' or 0.")
    if mode == "binary":
        y = pd.Series(np.where(benign_mask, BINARY_NORMAL, BINARY_SUSPICIOUS), index=series.index, dtype=object)
        return y, BINARY_NORMAL
    benign_label = s[benign_mask].value_counts().idxmax()
    y = s.where(~benign_mask, benign_label).astype(object)
    return y, benign_label


def _estimator(model_type: str):
    if model_type == "Logistic Regression":
        return LogisticRegression(max_iter=500, class_weight="balanced")
    return RandomForestClassifier(n_estimators=100, max_depth=18, min_samples_leaf=2,
                                  class_weight="balanced_subsample", n_jobs=-1, random_state=42)


# --------------------------------------------------------------------------- prediction
def predict_frame(bundle: ModelBundle, df: pd.DataFrame) -> pd.DataFrame:
    """Score a frame. Returns prediction, is_suspicious, risk_score, confidence."""
    X, _ = prepare_features(df, bundle.numeric_columns, bundle.categorical_columns, bundle.feature_columns)
    if len(X) == 0:
        return pd.DataFrame({"prediction": [], "is_suspicious": [], "risk_score": [], "confidence": []},
                            index=df.index)
    proba = bundle.pipeline.predict_proba(X)
    classes = [str(c) for c in bundle.pipeline.classes_]
    bi = classes.index(bundle.benign_label)
    p_benign = proba[:, bi]
    risk = (1.0 - p_benign) * 100.0
    susp = risk >= 50.0
    masked = proba.copy()
    masked[:, bi] = -1.0
    attack_idx = masked.argmax(axis=1)
    cls = np.array(classes, dtype=object)
    pred = np.where(susp, cls[attack_idx], bundle.benign_label)
    pred_idx = np.where(susp, attack_idx, bi)
    conf = proba[np.arange(len(proba)), pred_idx] * 100.0
    return pd.DataFrame({"prediction": pred, "is_suspicious": susp,
                         "risk_score": np.round(risk, 1), "confidence": np.round(conf, 1)}, index=df.index)


def class_probabilities(bundle: ModelBundle, df: pd.DataFrame) -> dict:
    X, _ = prepare_features(df, bundle.numeric_columns, bundle.categorical_columns, bundle.feature_columns)
    proba = bundle.pipeline.predict_proba(X)[0]
    return {str(c): float(p) for c, p in zip(bundle.pipeline.classes_, proba)}


# --------------------------------------------------------------------------- importances
def _aggregate_importances(pipeline: Pipeline, numeric, categorical) -> dict:
    pre, clf = pipeline.named_steps["pre"], pipeline.named_steps["clf"]
    try:
        names = list(pre.get_feature_names_out())
    except Exception:
        return {}
    if hasattr(clf, "feature_importances_"):
        raw = np.asarray(clf.feature_importances_, dtype=float)
    elif hasattr(clf, "coef_"):
        raw = np.abs(np.asarray(clf.coef_)).mean(axis=0)
    else:
        return {}
    if len(raw) != len(names):
        return {}
    agg = {}
    for name, val in zip(names, raw):
        if name.startswith("num__"):
            col = name[5:]
        else:
            body = name[5:] if name.startswith("cat__") else name
            matches = [c for c in categorical if body.startswith(c + "_")]
            col = max(matches, key=len) if matches else body
        agg[col] = agg.get(col, 0.0) + float(val)
    total = sum(agg.values()) or 1.0
    return dict(sorted(((k, v / total) for k, v in agg.items()), key=lambda kv: -kv[1]))


# --------------------------------------------------------------------------- training
def _fit_bundle(model_type, X_train, y_train, numeric, categorical, benign_label, **meta) -> ModelBundle:
    pipe = Pipeline([("pre", build_preprocessor(numeric, categorical)), ("clf", _estimator(model_type))])
    pipe.fit(X_train, y_train)  # fitted on the training split only
    return ModelBundle(pipeline=pipe, feature_columns=list(X_train.columns), numeric_columns=list(numeric),
                       categorical_columns=list(categorical), classes=[str(c) for c in pipe.classes_],
                       benign_label=benign_label, model_type=model_type, **meta)


def _split_eval(bundle, X, y) -> dict:
    pf = predict_frame(bundle, X)
    return evaluation.evaluate_split(y.to_numpy(), pf["prediction"].to_numpy(), pf["is_suspicious"].to_numpy(),
                                     pf["risk_score"].to_numpy(), bundle.benign_label, bundle.classes)


def train_model(df: pd.DataFrame, label_col: str, feature_cols, model_type: str = "Random Forest",
                target_mode: str = "multiclass", test_size: float = 0.25, random_state: int = 42,
                source: str = "", synthetic: bool = False, compare_baseline: bool = False,
                max_rows: int = 100_000):
    """Train + evaluate. Returns ``(bundle, warnings)``. Raises DataError / ModelError."""
    warnings = []
    if label_col not in df.columns:
        raise DataError(f"Label column '{label_col}' was not found in the dataset.")
    feature_cols = [c for c in feature_cols if c in df.columns and c != label_col]
    if not feature_cols:
        raise DataError("Select at least one feature column (other than the label).")

    data = df[feature_cols + [label_col]]
    n0 = len(data)
    data = data[data[label_col].notna()]
    if len(data) < n0:
        warnings.append(f"Dropped {n0 - len(data):,} rows with a missing label.")
    if len(data) < 30:
        raise DataError("At least 30 labelled rows are needed to train and evaluate a model.")

    y, benign_label = prepare_target(data[label_col], target_mode)
    counts = y.value_counts()
    rare = counts[counts < 2].index.tolist()
    if rare:
        warnings.append(f"Removed classes with fewer than 2 rows (cannot be split): {', '.join(map(str, rare))}.")
        keep = ~y.isin(rare)
        data, y = data[keep], y[keep]
    if y.nunique() < 2 or benign_label not in set(y.unique()):
        raise DataError("The label column must contain a benign class and at least one attack class.")

    if len(data) > max_rows:
        try:
            data, _ = train_test_split(data, train_size=max_rows, stratify=y, random_state=random_state)
        except ValueError:
            data = data.sample(max_rows, random_state=random_state)
        y = y.loc[data.index]
        warnings.append(f"Large dataset: a sample of {max_rows:,} rows was used for training/evaluation.")

    numeric, categorical = split_feature_types(data, feature_cols)
    all_nan = [c for c in feature_cols if data[c].isna().all()]
    if all_nan:
        raise DataError(f"These features contain no values: {', '.join(all_nan)}. Remove them and retry.")
    X, report = prepare_features(data, numeric, categorical, feature_cols)
    if report["coerced"]:
        warnings.append("Some numeric values could not be parsed and were treated as missing: " +
                        ", ".join(f"{k} ({v:,})" for k, v in list(report["coerced"].items())[:5]))

    stratify = y
    try:
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=test_size, stratify=stratify,
                                                  random_state=random_state)
    except ValueError:
        warnings.append("Stratified split was not possible; a random split was used instead.")
        X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=test_size, random_state=random_state)
    if y_tr.nunique() < 2:
        raise DataError("The training split contains only one class. Provide more varied data.")

    meta = dict(target_mode=target_mode, label_column=label_col, source=source, synthetic=synthetic,
                trained_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), n_train=len(X_tr), n_test=len(X_te))
    try:
        bundle = _fit_bundle(model_type, X_tr, y_tr, numeric, categorical, benign_label, **meta)
    except Exception as exc:  # sklearn raises many types
        raise ModelError(f"Training failed: {exc}") from exc

    # Reference statistics come from the TRAINING split only.
    ref = {"overall": {}, "by_class": {}}
    if numeric:
        q = X_tr[numeric].quantile([0.25, 0.5, 0.75])
        for c in numeric:
            ref["overall"][c] = {"q1": _f(q.loc[0.25, c]), "median": _f(q.loc[0.5, c]), "q3": _f(q.loc[0.75, c])}
        med = X_tr[numeric].groupby(y_tr).median()
        for cls_name in med.index:
            ref["by_class"][str(cls_name)] = {c: _f(med.loc[cls_name, c]) for c in numeric}
    bundle.reference_stats = ref
    bundle.category_values = {c: sorted(map(str, X_tr[c].dropna().unique()))[:50] for c in categorical}
    bundle.importances = _aggregate_importances(bundle.pipeline, numeric, categorical)

    ev = {"train": _split_eval(bundle, X_tr, y_tr), "test": _split_eval(bundle, X_te, y_te),
          "rows_used": int(len(X)), "test_size": float(test_size), "warnings": warnings,
          "class_counts_all": {str(k): int(v) for k, v in y.value_counts().items()}}
    if compare_baseline:
        other = "Logistic Regression" if model_type == "Random Forest" else "Random Forest"
        try:
            ob = _fit_bundle(other, X_tr, y_tr, numeric, categorical, benign_label, **meta)
            ev["comparison"] = {"model_type": other, "test": _split_eval(ob, X_te, y_te)["binary"]}
        except Exception as exc:
            warnings.append(f"Comparison model failed: {exc}")
    bundle.evaluation = ev
    return bundle, warnings


def _f(v):
    try:
        v = float(v)
        return v if np.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def train_default_demo_model() -> ModelBundle:
    df = demo_data.generate_training_set(n=6000, seed=7)
    bundle, _ = train_model(df, "label", DEFAULT_FEATURES, "Random Forest", "multiclass", 0.25, 42,
                            source="Synthetic demonstration dataset (generated locally)", synthetic=True)
    return bundle


# --------------------------------------------------------------------------- explanation
def explain_record(bundle: ModelBundle, rec: dict, compare_label: str, top_n: int = 6) -> list:
    """Compare input values with training-set medians (a reference comparison, not SHAP)."""
    ref = bundle.reference_stats or {}
    normal = ref.get("by_class", {}).get(bundle.benign_label, {})
    other = ref.get("by_class", {}).get(compare_label, {})
    rows = []
    for col, imp in bundle.importances.items():
        if col not in bundle.numeric_columns or col not in rec:
            continue
        v, nm, om = rec[col], normal.get(col), other.get(col)
        if v is None or nm is None or om is None:
            continue
        d_n = abs(np.log1p(max(v, 0)) - np.log1p(max(nm, 0)))
        d_o = abs(np.log1p(max(v, 0)) - np.log1p(max(om, 0)))
        rows.append({"feature": col, "your_value": v, "normal_median": nm, "compare_median": om,
                     "closer_to": "Normal" if d_n <= d_o else compare_label, "importance": imp})
    return rows[:top_n]


def rule_based_assessment(rec: dict) -> dict:
    """Transparent heuristic used ONLY when no trained model is available."""
    rules = []
    rate, bwd = rec.get("flow_packets_per_s", 0), rec.get("total_bwd_packets", 0)
    tot = rec.get("total_fwd_packets", 0) + bwd
    if rate > 2000 and bwd <= 2:
        rules.append((60, "DoS / DDoS", "Very high packet rate with almost no replies (flood-like)."))
    if tot <= 3 and rec.get("flow_duration", 0) < 50:
        rules.append((45, "Port Scanning", "Tiny, very short flow (probe-like)."))
    if rec.get("dst_port") in (22, 3389, 21, 23) and 8 <= rec.get("total_fwd_packets", 0) <= 60 \
            and rec.get("pkt_len_mean", 999) < 200:
        rules.append((45, "Brute-Force Attempts", "Repeated small exchanges with a login service port."))
    if rec.get("dst_port") in (6667, 4444, 1337):
        rules.append((45, "Botnet Activity", "Destination port commonly used by command-and-control tools."))
    score = min(100, sum(r[0] for r in rules))
    top = max(rules, key=lambda r: r[0])[1] if rules else BINARY_NORMAL
    return {"prediction": top if score >= 50 else BINARY_NORMAL, "risk_score": float(score),
            "reasons": [r[2] for r in rules] or ["No simple rule matched."],
            "method": "Rule-based demonstration (no machine learning)"}


# --------------------------------------------------------------------------- persistence
def save_model(bundle: ModelBundle, path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(bundle, path, compress=3)
    return path


def load_model(path):
    """Load a bundle saved by this app. Returns None if missing or incompatible.

    Only load files you created yourself: joblib/pickle can execute code.
    """
    path = Path(path)
    if not path.exists():
        return None
    try:
        obj = joblib.load(path)
    except Exception:
        return None
    if isinstance(obj, ModelBundle) and obj.schema_version == SCHEMA_VERSION:
        return obj
    return None
