"""Dataset-independent preprocessing helpers (no Streamlit code here)."""
from __future__ import annotations

import re

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

DEFAULT_FEATURES = [
    "protocol", "src_port", "dst_port", "flow_duration",
    "total_fwd_packets", "total_bwd_packets", "total_fwd_bytes", "total_bwd_bytes",
    "pkt_len_mean", "pkt_len_std", "flow_packets_per_s", "flow_bytes_per_s",
]

# normalised source column name -> canonical name used by this project
ALIASES = {
    "source_ip": "src_ip", "srcip": "src_ip", "src_ip_addr": "src_ip", "source_address": "src_ip",
    "destination_ip": "dst_ip", "dstip": "dst_ip", "dest_ip": "dst_ip", "destination_address": "dst_ip",
    "source_port": "src_port", "sport": "src_port", "srcport": "src_port",
    "destination_port": "dst_port", "dsport": "dst_port", "dport": "dst_port", "dstport": "dst_port",
    "proto": "protocol",
    "dur": "flow_duration",
    "tot_fwd_pkts": "total_fwd_packets", "spkts": "total_fwd_packets",
    "total_backward_packets": "total_bwd_packets", "tot_bwd_pkts": "total_bwd_packets", "dpkts": "total_bwd_packets",
    "total_length_of_fwd_packets": "total_fwd_bytes", "totlen_fwd_pkts": "total_fwd_bytes", "sbytes": "total_fwd_bytes",
    "total_length_of_bwd_packets": "total_bwd_bytes", "totlen_bwd_pkts": "total_bwd_bytes", "dbytes": "total_bwd_bytes",
    "packet_length_mean": "pkt_len_mean", "pkt_len_mean": "pkt_len_mean",
    "packet_length_std": "pkt_len_std",
    "flow_packets_s": "flow_packets_per_s", "flow_pkts_s": "flow_packets_per_s",
    "flow_bytes_s": "flow_bytes_per_s", "flow_byts_s": "flow_bytes_per_s",
    "stime": "timestamp", "ts": "timestamp", "time": "timestamp", "datetime": "timestamp",
}

LABEL_CANDIDATES = ["label", "class", "attack_cat", "attack_category", "attack", "target", "category", "y"]
LEAKY_NAMES = set(LABEL_CANDIDATES) | {"binary_label", "label_binary", "is_attack"}
ID_LIKE = {"timestamp", "src_ip", "dst_ip", "flow_id", "id", "index", "unnamed_0", "date"}

BENIGN_VALUES = {"normal", "benign", "normal traffic", "legitimate", "0", "0.0", "false", "none", "clean"}
PROTO_MAP = {"6": "TCP", "17": "UDP", "1": "ICMP", "58": "ICMPV6", "2": "IGMP"}


class DataError(ValueError):
    """Raised for problems the user can fix (shown as a friendly message)."""


def normalize_name(col) -> str:
    return re.sub(r"[^0-9a-zA-Z]+", "_", str(col).strip()).strip("_").lower()


def normalize_protocol(s: pd.Series) -> pd.Series:
    out = s.astype(str).str.strip().str.upper().str.replace(r"\.0$", "", regex=True)
    out = out.replace(PROTO_MAP)
    return out.astype(object).where(s.notna(), np.nan)


def canonicalize(df: pd.DataFrame):
    """Normalise column names, apply aliases, clean inf values.

    Returns ``(clean_df, renamed)`` where ``renamed`` maps original -> new names.
    """
    original = list(df.columns)
    out = df.copy()
    out.columns = [normalize_name(c) for c in original]
    out = out.loc[:, ~out.columns.duplicated()]
    renamed, mapping, taken = {}, {}, set(out.columns)
    for col in list(out.columns):
        target = ALIASES.get(col)
        if target and target != col and target not in taken and target not in mapping.values():
            mapping[col] = target
    out = out.rename(columns=mapping)
    for o, n in zip(original, [normalize_name(c) for c in original]):
        final = mapping.get(n, n)
        if str(o) != final:
            renamed[str(o)] = final
    if "protocol" in out.columns:
        out["protocol"] = normalize_protocol(out["protocol"])
    num = out.select_dtypes(include=[np.number]).columns
    if len(num):
        out[num] = out[num].replace([np.inf, -np.inf], np.nan)
    return out, renamed


def is_benign_label(v) -> bool:
    return str(v).strip().lower() in BENIGN_VALUES


def detect_label_column(df: pd.DataFrame):
    for c in LABEL_CANDIDATES:
        if c in df.columns:
            return c
    return None


def _is_numeric_like(s: pd.Series) -> bool:
    if pd.api.types.is_bool_dtype(s) or pd.api.types.is_numeric_dtype(s):
        return True
    nn = s.dropna()
    if nn.empty:
        return False
    sample = nn.iloc[:2000]
    return pd.to_numeric(sample, errors="coerce").notna().mean() > 0.95


def split_feature_types(df: pd.DataFrame, cols):
    numeric, categorical = [], []
    for c in cols:
        (numeric if _is_numeric_like(df[c]) else categorical).append(c)
    return numeric, categorical


def suggest_features(df: pd.DataFrame, label_col=None, max_cardinality: int = 30):
    """Return (features, dropped) where dropped = [(column, reason)]."""
    feats, dropped = [], []
    for c in df.columns:
        if c == label_col:
            continue
        if c in ID_LIKE:
            dropped.append((c, "identifier / timestamp"))
        elif c in LEAKY_NAMES:
            dropped.append((c, "looks like a label (possible target leakage)"))
        elif df[c].isna().all():
            dropped.append((c, "all values missing"))
        elif df[c].nunique(dropna=True) <= 1:
            dropped.append((c, "constant column"))
        elif _is_numeric_like(df[c]):
            feats.append(c)
        elif df[c].nunique(dropna=True) <= max_cardinality:
            feats.append(c)
        else:
            dropped.append((c, f"text column with more than {max_cardinality} distinct values"))
    return feats, dropped


def prepare_features(df: pd.DataFrame, numeric, categorical, features):
    """Build the model input frame (same code path for training and prediction).

    Missing columns are added as NaN (the pipeline imputer handles them).
    Returns ``(X, report)`` with report = {"missing": [...], "coerced": {col: n}}.
    """
    X = pd.DataFrame(index=df.index)
    missing, coerced = [], {}
    for c in features:
        if c not in df.columns:
            missing.append(c)
            X[c] = np.nan if c in numeric else np.array([np.nan] * len(df), dtype=object)
            continue
        s = df[c]
        if c in numeric:
            conv = pd.to_numeric(s, errors="coerce").astype(float)
            conv = conv.replace([np.inf, -np.inf], np.nan)
            bad = int(conv.isna().sum() - s.isna().sum())
            if bad > 0:
                coerced[c] = bad
            X[c] = conv
        else:
            txt = s.astype(str).str.strip()
            if c == "protocol":
                txt = normalize_protocol(s)
            X[c] = txt.astype(object).where(s.notna(), np.nan)
    return X[list(features)], {"missing": missing, "coerced": coerced}


def build_preprocessor(numeric, categorical) -> ColumnTransformer:
    parts = []
    if numeric:
        parts.append(("num", Pipeline([("imputer", SimpleImputer(strategy="median")),
                                       ("scaler", StandardScaler())]), list(numeric)))
    if categorical:
        parts.append(("cat", Pipeline([
            ("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))]), list(categorical)))
    if not parts:
        raise DataError("No usable feature columns were selected.")
    return ColumnTransformer(parts, remainder="drop")


def validate_manual_record(rec: dict):
    """Validate the manual form values. Returns (errors, warnings)."""
    errors, warnings = [], []
    for k in ("src_port", "dst_port"):
        v = rec.get(k)
        if v is None or not (0 <= v <= 65535):
            errors.append(f"{k.replace('_', ' ').title()} must be between 0 and 65535.")
    for k in ("flow_duration", "total_fwd_packets", "total_bwd_packets", "total_fwd_bytes",
              "total_bwd_bytes", "pkt_len_mean", "pkt_len_std", "flow_packets_per_s", "flow_bytes_per_s"):
        v = rec.get(k)
        if v is None or not np.isfinite(v) or v < 0:
            errors.append(f"{k.replace('_', ' ').capitalize()} must be a non-negative number.")
    if errors:
        return errors, warnings
    pk = rec["total_fwd_packets"] + rec["total_bwd_packets"]
    by = rec["total_fwd_bytes"] + rec["total_bwd_bytes"]
    if pk == 0 and by > 0:
        errors.append("Byte counts are greater than zero but there are no packets.")
    if pk == 0 and by == 0:
        errors.append("A flow needs at least one packet.")
    if pk > 0 and by == 0:
        warnings.append("Packets were entered but total bytes are zero.")
    if pk > 0 and by > 0 and (by / pk) > 65535:
        warnings.append("Average packet size is above 65,535 bytes, which is not physically possible.")
    if rec.get("protocol") == "ICMP" and (rec["src_port"] or rec["dst_port"]):
        warnings.append("ICMP does not use ports; the port values may be ignored in real datasets.")
    return errors, warnings
