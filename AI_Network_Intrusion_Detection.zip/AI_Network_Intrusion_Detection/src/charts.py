"""Plotly chart builders with a shared dark theme. Every function tolerates missing data."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from .config import CATEGORY_COLORS, COLORS, SEVERITY_COLORS

FONT = "Inter, Segoe UI, system-ui, sans-serif"
GRID = "#1A2641"


def style(fig: go.Figure, height: int = 320, title: str | None = None, legend: bool = True) -> go.Figure:
    fig.update_layout(
        height=height, paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(family=FONT, color="#C5CFE3", size=12),
        title=dict(text=title, x=0.0, xanchor="left", font=dict(family="Space Grotesk, Inter, Segoe UI, sans-serif",
                                                                   size=16, color=COLORS["text"])) if title else None,
        margin=dict(l=8, r=8, t=48 if title else 16, b=8),
        showlegend=legend,
        legend=dict(orientation="h", yanchor="bottom", y=1.0, xanchor="right", x=1.0, bgcolor="rgba(0,0,0,0)",
                    font=dict(size=11)),
        hoverlabel=dict(bgcolor="#0C1322", bordercolor="#2A3A5E", font=dict(family=FONT, color="#E8EEF9")),
        colorway=[COLORS["green"], COLORS["cyan"], COLORS["amber"], COLORS["red"], COLORS["violet"]],
    )
    fig.update_xaxes(gridcolor=GRID, zerolinecolor=GRID, linecolor=GRID, tickfont=dict(size=11), automargin=True)
    fig.update_yaxes(gridcolor=GRID, zerolinecolor=GRID, linecolor=GRID, tickfont=dict(size=11), automargin=True)
    return fig


def empty(message: str, height: int = 280, title: str | None = None) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=message, x=0.5, y=0.5, xref="paper", yref="paper", showarrow=False,
                       font=dict(size=13, color=COLORS["muted"]))
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    return style(fig, height, title, legend=False)


def _bucket(span: pd.Timedelta) -> str:
    secs = max(span.total_seconds(), 1)
    for freq, step in [("10s", 10), ("30s", 30), ("1min", 60), ("5min", 300), ("15min", 900),
                       ("1h", 3600), ("6h", 21600), ("1D", 86400)]:
        if secs / step <= 90:
            return freq
    return "1D"


def _times(df, col="timestamp"):
    if col not in df.columns:
        return None
    t = pd.to_datetime(df[col], errors="coerce")
    return t if t.notna().sum() > 1 else None


def traffic_over_time(df: pd.DataFrame, title="Network traffic over time", height=330) -> go.Figure:
    t = _times(df)
    if t is None or "is_suspicious" not in df.columns:
        return empty("Needs a timestamp column and model predictions.", height, title)
    d = pd.DataFrame({"t": t, "Suspicious": df["is_suspicious"].astype(bool)}).dropna(subset=["t"])
    freq = _bucket(d["t"].max() - d["t"].min())
    g = d.groupby([pd.Grouper(key="t", freq=freq), "Suspicious"]).size().unstack(fill_value=0)
    for c in (False, True):
        if c not in g.columns:
            g[c] = 0
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=g.index, y=g[False], name="Normal", mode="lines", stackgroup="a",
                             line=dict(width=1.5, color=COLORS["green"]), fillcolor="rgba(34,227,160,0.22)",
                             hovertemplate="%{x|%H:%M:%S}<br>%{y} normal flows<extra></extra>"))
    fig.add_trace(go.Scatter(x=g.index, y=g[True], name="Suspicious", mode="lines", stackgroup="a",
                             line=dict(width=1.5, color=COLORS["red"]), fillcolor="rgba(239,68,68,0.35)",
                             hovertemplate="%{x|%H:%M:%S}<br>%{y} suspicious flows<extra></extra>"))
    fig.update_yaxes(title_text="Flows per interval")
    return style(fig, height, title)


def donut(labels, values, colors, title, height=330, center_text=None) -> go.Figure:
    if len(values) == 0 or sum(values) == 0:
        return empty("No data to display.", height, title)
    fig = go.Figure(go.Pie(labels=labels, values=values, hole=0.66, sort=False,
                           marker=dict(colors=colors, line=dict(color="#0C1322", width=3)),
                           textinfo="percent", textfont=dict(size=12, color="#0C1322"),
                           hovertemplate="%{label}<br>%{value:,} flows (%{percent})<extra></extra>"))
    if center_text:
        fig.add_annotation(text=center_text, x=0.5, y=0.5, showarrow=False,
                           font=dict(family="Space Grotesk, Inter, Segoe UI, sans-serif", size=22, color=COLORS["text"]))
    fig = style(fig, height, title)
    fig.update_layout(legend=dict(orientation="h", yanchor="top", y=-0.02, xanchor="center", x=0.5),
                      margin=dict(l=8, r=8, t=48, b=36))
    return fig


def category_bar(counts: pd.Series, title="Attack category distribution", height=330) -> go.Figure:
    counts = counts[counts > 0].sort_values()
    if counts.empty:
        return empty("No suspicious traffic in this dataset.", height, title)
    colors = [CATEGORY_COLORS.get(c, COLORS["amber"]) for c in counts.index]
    fig = go.Figure(go.Bar(x=counts.values, y=counts.index, orientation="h", marker=dict(color=colors),
                           hovertemplate="%{y}: %{x:,}<extra></extra>"))
    fig.update_xaxes(title_text="Flows")
    return style(fig, height, title, legend=False)


def severity_bar(counts: pd.Series, title="Alert severity distribution", height=330) -> go.Figure:
    order = ["Critical", "High", "Medium", "Low", "Informational"]
    vals = [int(counts.get(s, 0)) for s in order]
    if sum(vals) == 0:
        return empty("No alerts to display.", height, title)
    fig = go.Figure(go.Bar(x=order, y=vals, marker=dict(color=[SEVERITY_COLORS[s] for s in order]),
                           hovertemplate="%{x}: %{y:,}<extra></extra>"))
    fig.update_yaxes(title_text="Alerts")
    return style(fig, height, title, legend=False)


def top_bar(counts: pd.Series, title, color=None, height=300, xlabel="Flows") -> go.Figure:
    counts = counts.sort_values().tail(12)
    if counts.empty:
        return empty("Column not available in this dataset.", height, title)
    fig = go.Figure(go.Bar(x=counts.values, y=counts.index.astype(str), orientation="h",
                           marker=dict(color=color or COLORS["cyan"]),
                           hovertemplate="%{y}: %{x:,}<extra></extra>"))
    fig.update_xaxes(title_text=xlabel)
    fig.update_yaxes(type="category")
    return style(fig, height, title, legend=False)


def volume_over_time(df: pd.DataFrame, title="Traffic volume over time", height=320) -> go.Figure:
    t = _times(df)
    bcols = [c for c in ("total_fwd_bytes", "total_bwd_bytes") if c in df.columns]
    if t is None:
        return empty("No timestamp column found.", height, title)
    d = pd.DataFrame({"t": t, "flows": 1})
    if bcols:
        d["bytes"] = sum(pd.to_numeric(df[c], errors="coerce").fillna(0) for c in bcols)
    d = d.dropna(subset=["t"])
    freq = _bucket(d["t"].max() - d["t"].min())
    g = d.groupby(pd.Grouper(key="t", freq=freq)).sum()
    fig = go.Figure()
    if bcols:
        fig.add_trace(go.Bar(x=g.index, y=g["bytes"] / 1e6, name="Volume (MB)", marker=dict(color="rgba(34,211,238,0.55)"),
                             hovertemplate="%{x|%H:%M:%S}<br>%{y:.2f} MB<extra></extra>"))
    fig.add_trace(go.Scatter(x=g.index, y=g["flows"], name="Flows", yaxis="y2", mode="lines",
                             line=dict(color=COLORS["green"], width=2),
                             hovertemplate="%{x|%H:%M:%S}<br>%{y} flows<extra></extra>"))
    fig.update_layout(yaxis=dict(title="Megabytes"), yaxis2=dict(title="Flows", overlaying="y", side="right",
                                                                  gridcolor="rgba(0,0,0,0)"))
    return style(fig, height, title)


def histogram(values, title, xlabel, color=None, height=300, log_x=False, nbins=40) -> go.Figure:
    v = pd.to_numeric(pd.Series(values), errors="coerce").dropna()
    if v.empty:
        return empty("No numeric values available.", height, title)
    if log_x:
        v = np.log10(v.clip(lower=0) + 1)
        xlabel = f"log10({xlabel} + 1)"
    fig = go.Figure(go.Histogram(x=v, nbinsx=nbins, marker=dict(color=color or COLORS["cyan"],
                                                                line=dict(color="#0C1322", width=1))))
    fig.update_xaxes(title_text=xlabel)
    fig.update_yaxes(title_text="Flows")
    return style(fig, height, title, legend=False)


def confusion_heatmap(cm, labels, title, height=340) -> go.Figure:
    cm = np.asarray(cm)
    if cm.size == 0:
        return empty("No data.", height, title)
    norm = cm / np.maximum(cm.sum(axis=1, keepdims=True), 1)
    text = [[f"{cm[i][j]:,}" for j in range(cm.shape[1])] for i in range(cm.shape[0])]
    fig = go.Figure(go.Heatmap(z=norm, x=labels, y=labels, text=text, texttemplate="%{text}",
                               colorscale=[[0, "#0C1322"], [1, COLORS["green"]]], showscale=False, zmin=0, zmax=1,
                               hovertemplate="Actual %{y}<br>Predicted %{x}<br>%{text} flows<extra></extra>"))
    fig.update_xaxes(title_text="Predicted", side="bottom")
    fig.update_yaxes(title_text="Actual", autorange="reversed")
    return style(fig, height, title, legend=False)


def roc_fig(roc, auc, title="ROC curve (Normal vs Suspicious)", height=320) -> go.Figure:
    if not roc:
        return empty("ROC needs both classes in the test set.", height, title)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", line=dict(dash="dot", color=COLORS["slate"]),
                             name="Chance", hoverinfo="skip"))
    fig.add_trace(go.Scatter(x=roc["fpr"], y=roc["tpr"], mode="lines", line=dict(color=COLORS["green"], width=2.5),
                             name=f"Model (AUC {auc:.3f})" if auc is not None else "Model",
                             hovertemplate="FPR %{x:.3f}<br>TPR %{y:.3f}<extra></extra>"))
    fig.update_xaxes(title_text="False positive rate", range=[0, 1])
    fig.update_yaxes(title_text="True positive rate (recall)", range=[0, 1.02])
    return style(fig, height, title)


def metrics_compare(train: dict, test: dict, title="Training vs test-set performance", height=320) -> go.Figure:
    keys = [("accuracy", "Accuracy"), ("precision", "Precision"), ("recall", "Recall"), ("f1", "F1-score")]
    fig = go.Figure()
    fig.add_trace(go.Bar(name="Training split", x=[k[1] for k in keys], y=[train.get(k[0]) or 0 for k in keys],
                         marker=dict(color=COLORS["slate"]), hovertemplate="%{x}: %{y:.3f}<extra>Training</extra>"))
    fig.add_trace(go.Bar(name="Test split", x=[k[1] for k in keys], y=[test.get(k[0]) or 0 for k in keys],
                         marker=dict(color=COLORS["green"]), hovertemplate="%{x}: %{y:.3f}<extra>Test</extra>"))
    fig.update_layout(barmode="group")
    fig.update_yaxes(range=[0, 1.05])
    return style(fig, height, title)


def importance_bar(importances: dict, title="Feature importance", height=340) -> go.Figure:
    if not importances:
        return empty("Not available for this model.", height, title)
    items = list(importances.items())[:12][::-1]
    fig = go.Figure(go.Bar(x=[v for _, v in items], y=[k for k, _ in items], orientation="h",
                           marker=dict(color=COLORS["cyan"]), hovertemplate="%{y}: %{x:.3f}<extra></extra>"))
    fig.update_xaxes(title_text="Relative importance")
    return style(fig, height, title, legend=False)


def prob_bar(probs: dict, height=250, title="Model score per class") -> go.Figure:
    items = sorted(probs.items(), key=lambda kv: kv[1])
    colors = [CATEGORY_COLORS.get(k, COLORS["amber"]) for k, _ in items]
    fig = go.Figure(go.Bar(x=[v * 100 for _, v in items], y=[k for k, _ in items], orientation="h",
                           marker=dict(color=colors), hovertemplate="%{y}: %{x:.1f}%<extra></extra>"))
    fig.update_xaxes(title_text="Share of model votes (%)", range=[0, 100])
    return style(fig, height, title, legend=False)


def gauge(score: float, height=230) -> go.Figure:
    color = COLORS["green"] if score < 40 else COLORS["amber"] if score < 60 else COLORS["orange"] if score < 80 else COLORS["red"]
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=score, number=dict(font=dict(family="Space Grotesk, Inter, Segoe UI, sans-serif", size=38, color=COLORS["text"]),
                                                      valueformat=".0f"),
        gauge=dict(axis=dict(range=[0, 100], tickcolor="#3A4A6B", tickfont=dict(size=10)),
                   bar=dict(color=color, thickness=0.28), bgcolor="#111B30", borderwidth=0,
                   steps=[dict(range=[0, 50], color="rgba(34,227,160,0.10)"),
                          dict(range=[50, 100], color="rgba(239,68,68,0.10)")],
                   threshold=dict(line=dict(color="#E8EEF9", width=2), value=50))))
    fig.update_layout(height=height, margin=dict(l=20, r=20, t=20, b=0), paper_bgcolor="rgba(0,0,0,0)",
                      font=dict(family=FONT))
    return fig
