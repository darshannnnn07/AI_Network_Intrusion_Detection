# data/

Put your own datasets here if you like (the app also lets you upload CSV files from anywhere).
No dataset is bundled, to keep the project small.

The built-in demo data is generated in memory by `src/demo_data.py` and is **synthetic**.
You can download a small synthetic sample CSV from the app (AI Intrusion Detection page) to try the upload feature.

## Compatible datasets
Any CSV with one row per network flow works. Column names from CIC-IDS style files
(for example `Destination Port`, `Flow Duration`, `Total Fwd Packets`, `Flow Bytes/s`, `Label`)
and UNSW-NB15 style names are matched to the standard names automatically. To train a model you
need a label column with a benign value (Normal, BENIGN or 0) and at least one attack class.
