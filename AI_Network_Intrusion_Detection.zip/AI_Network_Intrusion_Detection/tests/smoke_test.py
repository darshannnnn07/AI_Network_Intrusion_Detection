"""Automated checks. Run from the project folder:  python tests/smoke_test.py

Covers the ML core, CSV edge cases and every Streamlit page (rendered headlessly
with Streamlit's AppTest). It does not replace manual testing in a browser.
"""
import sys
import warnings
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from streamlit.testing.v1 import AppTest

from src import alerts, data_loader, demo_data, detection_model as dm
from src.preprocessing import DataError, canonicalize, validate_manual_record

PASSED, FAILED = [], []


def check(name, cond, detail=""):
    (PASSED if cond else FAILED).append(name)
    print(("PASS  " if cond else "FAIL  ") + name + (f"  {detail}" if detail and not cond else ""))


def raises(fn, exc):
    try:
        fn()
    except exc:
        return True
    except Exception:
        return False
    return False


# ---------------------------------------------------------------- core / ML
df = demo_data.generate_flows(3000, seed=1)
check("demo data has expected columns", list(df.columns) == demo_data.FLOW_COLUMNS)
bundle = dm.train_default_demo_model()
check("default model trains", bundle.model_type == "Random Forest" and bundle.synthetic)
te = bundle.evaluation["test"]["binary"]
check("test metrics are sensible", 0.8 < te["accuracy"] <= 1 and te["recall"] > 0.7)
check("train/test split recorded", bundle.n_train > bundle.n_test > 0)
pf = dm.predict_frame(bundle, df)
check("predict_frame output", {"prediction", "is_suspicious", "risk_score"} <= set(pf.columns) and len(pf) == len(df))
check("risk within 0-100", pf["risk_score"].between(0, 100).all())
check("suspicious flag matches risk>=50", ((pf["risk_score"] >= 50) == pf["is_suspicious"]).all())
sc = pf.assign(**{c: df[c] for c in ("timestamp", "src_ip", "dst_ip", "protocol", "dst_port")})
al = alerts.build_alerts(sc)
check("alerts built", len(al) > 0 and al["alert_id"].is_unique and set(al["severity"]) <= set(alerts.SEVERITY_ORDER))

# missing columns / unseen categories degrade gracefully
partial = df.drop(columns=["flow_bytes_per_s", "pkt_len_std"]).head(50)
check("missing features handled by imputer", len(dm.predict_frame(bundle, partial)) == 50)
weird = df.head(20).copy()
weird["protocol"] = "SCTP"
check("unseen category handled", len(dm.predict_frame(bundle, weird)) == 20)
check("empty frame handled", len(dm.predict_frame(bundle, df.head(0))) == 0)

# real-world style column names (CIC-IDS-like)
cic = pd.DataFrame({" Destination Port": [80, 443], " Flow Duration": [100, 200], "Total Fwd Packets": [2, 3],
                    " Flow Bytes/s": [np.inf, 10.0], " Protocol": [6, 17], " Label": ["BENIGN", "DDoS"]})
cc, ren = canonicalize(cic)
check("canonicalize maps names", {"dst_port", "flow_duration", "total_fwd_packets", "flow_bytes_per_s", "protocol", "label"} <= set(cc.columns))
check("protocol numbers mapped", list(cc["protocol"]) == ["TCP", "UDP"])
check("inf replaced by NaN", cc["flow_bytes_per_s"].isna().sum() == 1)

# training on a custom labelled frame, binary + LR + comparison
b2, w = dm.train_model(df, "label", demo_data.FEATURE_COLUMNS, "Logistic Regression", "binary", compare_baseline=True)
check("LR binary training", b2.classes == ["Normal Traffic", "Suspicious Traffic"] and "comparison" in b2.evaluation)
check("bad label column raises", raises(lambda: dm.train_model(df, "nope", ["src_port"]), DataError))
single = df.copy(); single["label"] = "Normal Traffic"
check("single-class data raises", raises(lambda: dm.train_model(single, "label", demo_data.FEATURE_COLUMNS), DataError))
check("tiny data raises", raises(lambda: dm.train_model(df.head(10), "label", demo_data.FEATURE_COLUMNS), DataError))

# model persistence
tmp = ROOT / "models" / "_test_model.joblib"
dm.save_model(bundle, tmp)
check("model save/load round trip", dm.load_model(tmp) is not None)
tmp.unlink()
check("missing model file returns None", dm.load_model(ROOT / "models" / "nope.joblib") is None)

# CSV parsing edge cases
check("empty csv rejected", raises(lambda: data_loader.parse_csv_bytes(b""), DataError))
check("header-only csv rejected", raises(lambda: data_loader.parse_csv_bytes(b"a,b,c\n"), DataError))
def _garbage_ok():
    try:
        data_loader.parse_csv_bytes(b"\x00\x01\x02")
    except DataError:
        return True          # friendly rejection
    except Exception:
        return False         # unexpected crash
    return True              # parsed without crashing


check("binary garbage does not crash the loader", _garbage_ok())
check("semicolon delimiter detected", data_loader.parse_csv_bytes(b"a;b;c\n1;2;3\n4;5;6\n")[0].shape == (2, 3))
check("sample csv parses", data_loader.parse_csv_bytes(data_loader.sample_csv_bytes(200))[0].shape[0] == 200)

# manual validation
ok = dict(demo_data.PRESETS["Normal web session"], flow_packets_per_s=10.0, flow_bytes_per_s=100.0)
check("valid manual record", validate_manual_record(ok)[0] == [])
check("bad port rejected", validate_manual_record(dict(ok, dst_port=70000))[0] != [])
check("negative value rejected", validate_manual_record(dict(ok, flow_duration=-5))[0] != [])
check("no packets rejected", validate_manual_record(dict(ok, total_fwd_packets=0, total_bwd_packets=0))[0] != [])


# ---------------------------------------------------------------- pages
def run_page(name, setup=None):
    at = AppTest.from_file(str(ROOT / "views" / name), default_timeout=90)
    at.run()
    if setup:
        setup(at)
    return at


def clean(at):
    return not at.exception


for page in ["1_Security_Overview.py", "2_AI_Intrusion_Detection.py", "3_Threat_Alerts.py", "4_Traffic_Explorer.py",
             "5_Model_Performance.py", "6_System_Information.py", "7_Live_Monitor.py"]:
    at = run_page(page)
    check(f"page renders: {page}", clean(at), str([e.value for e in at.exception]))

# manual analysis: submit the form
at = run_page("2_AI_Intrusion_Detection.py")
submit = [b for b in at.button if "Analyze" in (b.label or "")]
if submit:
    submit[0].click().run()
check("manual analysis runs", clean(at) and not at.error, str([e.value for e in at.exception] + [e.value for e in at.error]))

# demo simulation controls
at = run_page("1_Security_Overview.py")
runs = [b for b in at.button if b.label == "Run new simulation"]
if runs:
    runs[0].click().run()
check("simulation button works", clean(at), str([e.value for e in at.exception]))

# training from the UI
at = run_page("5_Model_Performance.py")
go = [b for b in at.button if b.label == "Train and evaluate"]
if go:
    go[0].click().run()
check("UI training works", clean(at) and not at.error, str([e.value for e in at.exception] + [e.value for e in at.error]))

print(f"\n{len(PASSED)} passed, {len(FAILED)} failed")
sys.exit(1 if FAILED else 0)
